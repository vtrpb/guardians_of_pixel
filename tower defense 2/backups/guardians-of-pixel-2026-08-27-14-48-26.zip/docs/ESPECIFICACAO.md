# Especificação do jogo

## Identidade

- O nome oficial do jogo é **Guardians of Pixel**.
- A sigla visual usada nos emblemas do lobby e da partida é **GP**.
- **Pixel tower defense** permanece como descrição do gênero, sem fazer parte do nome oficial.

## Objetivo

Defender a torre-base no fim do caminho usando torres enquanto os inimigos avançam pelas waves.

## Menu inicial

- A partida inicia somente ao clicar em **Começar partida**.
- O menu oferece dez ações: **Começar partida**, **Fases**, **Álbum**, **Como jogar**, **Loja**, **Pacote Apoiador**, **Missões**, **Conquistas**, **Waves infinitas** e **Configurações**.
- **Começar partida** inicia a fase selecionada e informa seu número abaixo do botão.
- **Fases** abre o seletor da campanha e mostra quais fases estão concluídas, disponíveis ou bloqueadas.
- O Álbum de Figurinhas organiza torres, inimigos, Bosses, minas e skins já obtidos; cada item coletado reutiliza seu sprite pixelado real.
- **Como jogar** apresenta seis passos antes da partida: começa orientando a escolher uma torre desbloqueada com dinheiro suficiente e termina explicando que é preciso proteger a torre-base até a wave 20.
- **Configurações** abre o painel compartilhado de música, efeitos sonoros, iluminação e idioma sem iniciar uma partida.
- **Loja** abre o catálogo de defesas especiais e mostra o saldo de Fragmentos de Pixel.
- **Pacote Apoiador** abre uma oferta cosmética opcional que não altera atributos ou progressão.
- **Missões** abre o painel de objetivos semanais, progresso e recompensas disponíveis.
- **Conquistas** abre a coleção permanente de desafios concluídos e ainda bloqueados.
- **Waves infinitas** inicia a fase selecionada em um modo sem vitória na wave 20; a partida termina somente quando a base é invadida.
- O lobby não possui um botão separado de música; tocar, pausar e ajustar o volume ficam centralizados em **Configurações**.
- O rodapé do lobby mostra o saldo atual de Fragmentos de Pixel.

### Mudança: páginas de conteúdo em tela inteira no lobby

**Objetivo:** abrir as áreas de consulta imediatamente, sem obrigar o jogador a rolar o cartão principal do lobby até encontrar o conteúdo.
**Alterar:** apresentar **Fases**, **Álbum**, **Como jogar**, **Loja**, **Pacote Apoiador**, **Missões** e **Conquistas** como páginas que ocupam toda a área visível do lobby.
**Não alterar:** painel de **Configurações**, botões que iniciam partidas, transição e conversa do portal secreto, conteúdo, compras, recompensas, categorias, progressão, temas ou balanceamento.
**Aceitação:**
- Clicar em qualquer uma das sete áreas de consulta substitui visualmente o lobby por sua página desde o topo da tela, sem acrescentar o conteúdo abaixo dos botões principais.
- A página cobre toda a largura e a altura visível, preserva as cores do tema da fase selecionada e permanece acima do portal e das decorações do lobby.
- O cabeçalho com título, descrição e **Fechar ×** aparece no início da página; ao abrir, o foco vai para o botão de fechar.
- Quando a quantidade de cartões ultrapassa a altura disponível, somente a própria página recebe rolagem vertical; o cartão principal do lobby permanece parado atrás dela.
- **Fechar ×** ou `Esc` encerra a página, limpa seu conteúdo e devolve o foco ao botão do lobby que a abriu.
- Trocar categorias da Loja ou do Álbum e selecionar uma fase atualiza a página aberta sem retornar ao lobby.
- **Configurações** continua usando sua caixa central atual, sem ser transformada em página de tela inteira.
- O portal secreto mantém a transição fixa e o balão do Senhor do Tempo, sem receber o modo de página de tela inteira.

### Mudança: seletor de idioma

**Objetivo:** permitir que o jogador escolha o idioma da interface pelo próprio jogo.
**Alterar:** adicionar ao painel **Configurações** um grupo **Idioma** com as opções **Português**, **English** e **Español**.
**Não alterar:** mecânicas, balanceamento, progresso, recompensas, compras, áudio ou iluminação.
**Aceitação:**
- Sem uma preferência salva, o jogo inicia em português do Brasil.
- A opção ativa recebe destaque e expõe `aria-pressed="true"`; as outras permanecem inativas.
- A escolha muda imediatamente toda a interface localizada, inclusive quando uma tela interna já está aberta.
- Lobby, Fases, Loja, Álbum, Como jogar, tutorial guiado, Missões, Conquistas, Pacote Apoiador, menus da partida, resultados, minigames, HUD e avisos acompanham o idioma ativo.
- Nomes e descrições vindos de `CONFIG`, incluindo torres, explosivos, inimigos, melhorias, skins, emblemas, missões, conquistas, fases e bônus, são localizados no momento da exibição sem alterar seus valores de balanceamento.
- O atributo `lang` do documento acompanha `pt-BR`, `en` ou `es` para auxiliar leitores de tela.
- A escolha fica salva localmente na chave `guardians-of-pixel-idioma-v1` e é restaurada ao recarregar a página.
- Valores de idioma desconhecidos são ignorados e o jogo usa português do Brasil como alternativa segura.

### Mudança: preferências de áudio e iluminação persistentes

**Objetivo:** manter a configuração escolhida pelo jogador depois que a página for fechada ou atualizada.
**Alterar:** salvar volume da música, estado silenciado da música, volume dos efeitos, estado ativado dos efeitos e modo dia/noite.
**Não alterar:** faixas, efeitos, volume padrão de primeiro acesso, iluminação de cada modo, mecânicas ou balanceamento.
**Aceitação:**
- O jogo salva as preferências na chave `guardians-of-pixel-preferencias-v1` sempre que um controle correspondente é alterado.
- Ao recarregar, os dois seletores de volume, os botões de áudio, o modo noturno e seus estados acessíveis refletem os valores salvos.
- Valores de volume são limitados ao intervalo de 0 a 1; dados ausentes, inválidos ou inacessíveis usam 35% para música, 80% para efeitos, efeitos ativos e modo dia.
- O último volume audível de cada grupo também é preservado para que reativar um áudio não use volume zero.

### Mudança: confirmação das compras da Loja

**Objetivo:** impedir gastos acidentais de Fragmentos de Pixel.
**Alterar:** abrir uma confirmação antes de concluir qualquer compra permanente da Loja.
**Não alterar:** catálogo, preços, saldo inicial, desbloqueios, categorias, recompensas ou efeitos dos itens comprados.
**Aceitação:**
- Clicar em **Comprar** na Loja abre uma caixa com nome do item, preço e saldo restante, sem descontar Fragmentos.
- **Cancelar**, clicar fora da caixa ou pressionar `Esc` fecha a confirmação sem alterar saldo ou compras e devolve o foco ao botão de origem.
- O botão final **Comprar** verifica novamente item, saldo e compra anterior antes de descontar qualquer Fragmento.
- Uma confirmação aceita realiza uma única compra, salva o novo saldo e preserva todos os desbloqueios já existentes.

### Mudança: avisos de missão e conquista concluídas

**Objetivo:** informar imediatamente um novo marco sem interromper a partida.
**Alterar:** exibir avisos temporários enfileirados quando uma missão cruza seu objetivo ou uma conquista é desbloqueada.
**Não alterar:** critérios, objetivos, recompensas, resgate de missões, salvamento ou pausa da partida.
**Aceitação:**
- O aviso de missão informa o nome da missão e orienta a abrir **Missões** para resgatar o prêmio.
- O aviso de conquista informa nome e descrição do marco desbloqueado.
- Avisos usam uma região `aria-live="polite"`, aparecem sobre o jogo sem bloquear cliques e são exibidos um por vez.
- Uma missão já concluída e uma conquista já salva não geram o mesmo aviso novamente.
- Títulos, nomes e descrições acompanham português, inglês e espanhol.

### Mudança: tutorial guiado da primeira partida

**Objetivo:** ensinar novos jogadores a iniciar sua primeira defesa praticando as ações essenciais antes que os inimigos avancem.
**Alterar:** abrir automaticamente o guia para quem ainda não o concluiu e conduzir a primeira partida normal por cinco passos: entender o objetivo, escolher a Torre padrão, construí-la fora do caminho, selecioná-la e liberar a primeira wave.
**Não alterar:** dinheiro inicial, custos, atributos, quantidade ou composição das waves, desbloqueios, recompensas, modo infinito ou regras de construção, melhoria e venda.
**Aceitação:**
- Um jogador sem registro do tutorial vê o painel **Como jogar** aberto no primeiro acesso ao lobby.
- Ao iniciar a primeira partida normal sem ter concluído o tutorial, a wave 1 fica pausada antes da criação do primeiro inimigo.
- O passo 1 explica que os inimigos percorrem o caminho até a torre-base e oferece continuar ou pular o tutorial.
- O passo 2 destaca a **Torre padrão** e avança somente quando ela é escolhida.
- O passo 3 destaca o mapa e avança somente depois que uma Torre padrão é construída em uma posição válida fora do caminho.
- O passo 4 pede que o jogador clique na torre construída e avança somente depois que ela é selecionada.
- O passo 5 explica prioridade de alvo, melhoria e venda; clicar em **Começar defesa** encerra o tutorial e libera a wave 1.
- Em todos os passos, o painel do treinamento permanece acima do mapa e dos elementos destacados, com título, descrição e botões totalmente legíveis.
- Enquanto o tutorial guiado está ativo, inimigos, waves e cronômetros permanecem pausados, e as ações de melhorar, vender e mudar prioridade não alteram a torre.
- **Pular tutorial** encerra o guia, libera a partida imediatamente e registra o tutorial como concluído.
- A conclusão fica salva localmente; partidas normais futuras começam sem o guia automático.
- O painel **Como jogar** mantém um resumo em seis passos e oferece **Jogar tutorial** para repetir o treinamento a qualquer momento.
- Iniciar **Waves infinitas** nunca abre automaticamente o tutorial guiado.

### Mudança: missões semanais

**Objetivo:** oferecer metas recorrentes que recompensem diferentes formas de jogar durante a semana.
**Alterar:** adicionar **Missões** ao lobby e registrar três objetivos semanais persistentes, renovados toda segunda-feira à 0h no horário local do jogador.
**Não alterar:** composição ou dificuldade das waves, recompensas normais de partida, custos da Loja, desbloqueio das fases, dano, créditos, torres ou regras do modo infinito.
**Aceitação:**
- O botão **Missões** aparece entre **Loja** e **Waves infinitas** e informa quantas recompensas estão prontas para resgate.
- O painel mostra a semana atual, a data da próxima renovação e três cartões com nome, descrição, progresso, objetivo e recompensa.
- **Caçador de Pixels** exige eliminar 50 inimigos em qualquer modo e recompensa 10 Fragmentos de Pixel; inimigos comuns, especiais e Bosses contam uma vez quando são derrotados.
- **Guardião da Campanha** exige concluir 3 partidas de campanha normal e desbloqueia a skin exclusiva **Sentinela Dourada** para a Torre padrão; derrotas, desistências e partidas infinitas não contam.
- **Além do Limite** exige alcançar a wave 40 no modo infinito e desbloqueia a conquista permanente **Além do Limite**; o progresso registra a maior wave alcançada na semana, sem somar waves de partidas diferentes.
- O progresso é salvo depois de cada eliminação, conclusão de fase ou novo recorde semanal do modo infinito e permanece após atualizar a página.
- Ao atingir o objetivo pela primeira vez na semana, um aviso informa que a missão foi concluída e que o prêmio deve ser resgatado no painel de Missões.
- Uma missão concluída libera o botão **Resgatar**; a recompensa só é adicionada ao saldo quando o jogador clica nele.
- Cada recompensa pode ser resgatada uma única vez e o estado de resgate permanece salvo durante a semana.
- A primeira obtenção da skin ou da conquista é permanente; em semanas futuras, resgatar novamente a missão correspondente concede respectivamente 15 ou 25 Fragmentos como recompensa alternativa.
- Ao desbloquear **Sentinela Dourada**, a skin é equipada automaticamente e altera somente as cores da Torre padrão em todos os níveis; o painel permite alternar entre a skin e o visual original sem alterar atributos.
- A conquista **Além do Limite** aparece permanentemente no painel **Conquistas** depois de resgatada.
- Quando a semana muda, progresso e resgates anteriores são substituídos por uma nova lista zerada; recompensas antigas não resgatadas expiram.
- Os valores de objetivo e recompensa ficam centralizados em `CONFIG.missoes`, permitindo adicionar categorias diárias e mensais futuramente.

### Mudança: painel de conquistas

**Objetivo:** registrar marcos permanentes do jogador e mostrar claramente quais desafios ainda faltam completar.
**Alterar:** adicionar **Conquistas** ao lobby, salvar estatísticas permanentes e exibir oito conquistas com nome, descrição, progresso e estado de desbloqueio.
**Não alterar:** recompensas das missões, saldo de Fragmentos, compras, progressão das fases, balanceamento, composição das waves ou regras de vitória e derrota.
**Aceitação:**
- O botão **Conquistas** aparece entre **Missões** e **Waves infinitas** e informa quantas das oito conquistas foram desbloqueadas.
- O painel mostra todas as conquistas desde o início; cartões bloqueados ficam mais escuros e totalmente em preto e branco, enquanto cartões desbloqueados recuperam as cores e exibem **Desbloqueada**.
- **Primeira Vigília** é desbloqueada ao concluir 1 partida da campanha normal.
- **Guardião dos Cinco Reinos** é desbloqueada ao concluir as cinco primeiras fases da campanha; a sexta fase não remove a conquista já obtida.
- **Guardião de Todos os Reinos** é desbloqueada ao concluir as sete fases da campanha normal.
- **Mestre do Arsenal** é desbloqueada ao comprar todos os itens disponíveis atualmente na Loja; novos itens adicionados ao catálogo passam a fazer parte desse total.
- **Lenda do Infinito** é desbloqueada ao alcançar a wave 100 no modo infinito.
- **Caçador de Pixels Supremo** é desbloqueada ao eliminar 500 inimigos ao longo de qualquer quantidade de partidas e em qualquer modo; inimigos comuns, especiais e Bosses contam uma vez.
- **Além do Limite** é uma conquista especial desbloqueada ao resgatar a missão semanal de alcançar a wave 40 no modo infinito.
- **???**, com a descrição **Ainda está te esperando, sempre vai estar.**, é uma conquista especial desbloqueada ao vencer a Dimensão Glitch.
- Estatísticas de eliminações, conclusões de campanha e maior wave infinita são permanentes e não reiniciam com a renovação semanal.
- Conquistas são verificadas após cada eliminação, vitória normal, nova maior wave infinita e compra da Loja, além de serem recalculadas ao carregar o jogo para reconhecer progresso e compras existentes.
- Cada novo desbloqueio exibe um aviso não bloqueante com o nome e a descrição da conquista.
- O desbloqueio de uma conquista não concede Fragmentos nem modifica torres; ele registra somente o marco permanente na coleção.
- Nomes, ícones, descrições, critérios e objetivos ficam centralizados em `CONFIG.conquistas`.

### Mudança: Pacote Apoiador cosmético

**Objetivo:** permitir que jogadores apoiem o desenvolvimento recebendo reconhecimento visual sem comprar vantagem competitiva.
**Alterar:** adicionar o botão **Pacote Apoiador** ao lobby, uma tela própria e uma demonstração local persistente do **Pacote Coração de Pixel**.
**Não alterar:** dano, alcance, cadência, créditos, Fragmentos, limites, recompensas, Loja, missões, conquistas, composição das waves ou progressão das fases.
**Aceitação:**
- O botão aparece entre **Loja** e **Missões** e passa a mostrar **Pacote ativo** depois da ativação.
- O pacote contém a skin **Aurora Pixel** para os quatro níveis da Torre padrão, o **Emblema Coração** no perfil e o **Selo Apoiador**.
- Todos os itens são cosméticos; a tela informa explicitamente que o pacote não aumenta dano, créditos, Fragmentos ou limite de torres.
- Enquanto `CONFIG.pacoteApoiador.modoDemonstracao` for verdadeiro, o botão principal exibe **Ativar demonstração** e avisa que nenhuma cobrança será feita.
- A demonstração salva aquisição e skin equipada na chave local `guardians-of-pixel-pacote-apoiador-v1` e mantém o pacote depois de atualizar a página.
- Ativar o pacote equipa automaticamente **Aurora Pixel** e substitui cores e detalhes de formato da Torre padrão, sem alterar seus atributos.
- O nível 0 usa uma estrutura compacta; o nível 1 acrescenta faixa luminosa, canhão mais longo e aletas laterais, sendo visualmente diferente em vez de apenas maior.
- Os níveis 2 e 3 acrescentam novos estabilizadores, luzes e núcleo central, mantendo cada evolução reconhecível.
- Equipar **Aurora Pixel** desequipa a skin de missão; equipar **Sentinela Dourada** desequipa **Aurora Pixel**, garantindo uma única skin ativa.
- No modo real, `CONFIG.pacoteApoiador.checkout` exige dois endpoints da mesma origem, token CSRF, contexto seguro e uma lista explícita de origens HTTPS permitidas para o provedor.
- O navegador envia somente o identificador `coracaoDePixel`; preço, moeda, usuário e produto válido são determinados pelo servidor.
- A URL retornada só é aberta quando usa HTTPS e pertence à lista de origens permitidas.
- Aquisição salva em `localStorage`, parâmetro de retorno ou resposta do navegador nunca libera o pacote no modo real; somente `GET` autenticado no servidor confirma o direito depois de um webhook de pagamento validado.
- O contrato de integração, segurança e homologação fica documentado em `docs/CHECKOUT_APOIADOR.md`.

## Menu da partida

- Durante a partida, um botão com três traços horizontais fica no canto superior direito do mapa.
- O botão exibe o indicador **ESC** e pode ser aberto ou fechado tanto pelo mouse quanto pela tecla `Esc`.
- O botão abre três ações: **Desistir**, **Reiniciar fase** e **Configurações**.
- Abrir o menu pausa imediatamente inimigos, torres, tiros, waves, avisos e cronômetros; fechar o menu continua a partida do mesmo ponto.
- **Desistir** abre uma confirmação que mostra a wave alcançada e a quantidade exata de Fragmentos de Pixel da recompensa.
- Confirmar **Desistir** concede a recompensa pelas waves, não conclui nem desbloqueia fases e apresenta o lobby em uma vinheta de 1,4 s que desliza do topo da tela.
- Escolher **Nunca!** fecha somente a confirmação e retorna ao menu pausado da fase, sem alterar a partida.
- **Reiniciar fase** recomeça imediatamente a fase selecionada na wave 1, com 150 créditos, sem torres e sem desbloquear fases.
- **Configurações** abre o mesmo painel disponível no lobby, mantém a partida pausada e oferece controles separados de volume da música e dos efeitos, botões independentes para silenciar cada grupo, o modo dia/noite e o seletor de idioma.
- O modo noite altera apenas a iluminação do lobby e do mapa; inimigos, balanceamento, progressão e trajetórias não são modificados.

### Mudança: partida sem cabeçalho redundante

**Objetivo:** ampliar o espaço vertical disponível para o mapa e manter somente informações úteis durante a defesa.
**Alterar:** remover da tela da partida o cabeçalho com **GP**, **Guardians of Pixel**, **Comando de defesa** e **Zona sob proteção**; reorganizar a aplicação em uma linha flexível para o mapa e outra para os controles inferiores.
**Não alterar:** título e identidade visual do lobby, mapa interno de 1.200 × 700 px, HUD, seletor de defesas, posto de boosts, menu de pausa ou barra inferior.
**Aceitação:**
- Ao iniciar qualquer fase ou o modo infinito, não existe faixa de marca acima do mapa.
- Em telas acima de 760 px, a aplicação ocupa exatamente a altura visível do navegador e o mapa reserva somente 116 px para margens, espaçamento e controles inferiores, em vez dos 170 px anteriores.
- O canvas cresce até encontrar primeiro o limite de largura ou a altura visível menos esses 116 px, preservando a proporção interna de 1.200 × 700 px, sem distorção, corte ou sobreposição da barra inferior.
- O seletor vertical de defesas acompanha a altura disponível do palco e permanece acima dos controles.
- O lobby continua exibindo o título principal **Guardians of Pixel** normalmente.

### Mudança: atalhos de teclado da partida

**Objetivo:** permitir jogar com teclado e mouse sem depender exclusivamente de cliques nos controles.
**Alterar:** adicionar `E` para melhorar a torre selecionada, `X` para vendê-la e `Esc` para abrir ou fechar o menu de pausa.
**Não alterar:** cliques do mouse, custos, valores de venda, requisitos de seleção, pausa, progressão ou balanceamento.
**Aceitação:**
- Dada uma torre selecionada durante a partida ativa, pressionar `E` executa a mesma ação do botão **Melhorar torre**.
- Dada uma torre selecionada durante a partida ativa, pressionar `X` executa a mesma ação do botão **Vender torre**.
- Durante a partida, pressionar `Esc` abre o menu e pausa o jogo; pressionar novamente fecha o menu e continua.
- Com as configurações abertas, `Esc` fecha as configurações antes de voltar a controlar o menu da partida.
- Durante telas de resultado, pausa ou configurações, `E` e `X` não executam ações.
- Os botões de melhorar, vender e pausar exibem respectivamente os indicadores **E**, **X** e **ESC**, mantendo também o funcionamento pelo mouse.

## Telas de resultado

- As telas de derrota e vitória permanecem abertas até o jogador escolher uma ação; não existe mais retorno ou reinício automático.
- No **GAME OVER**, os botões disponíveis são **Recomeçar fase** e **Voltar ao menu**.
- Na **VITÓRIA**, os botões disponíveis são **Repetir fase**, **Voltar ao menu** e **Próxima fase**.
- **Recomeçar fase** e **Repetir fase** iniciam a mesma fase na wave 1, com 150 créditos e sem torres.
- **Voltar ao menu** apresenta o lobby usando a mesma vinheta vertical aplicada ao menu de pausa.
- **Próxima fase** inicia imediatamente a fase seguinte já desbloqueada, sem passar pelo lobby.
- Na última fase disponível, **Próxima fase** permanece visível e desativado.

### Mudança: escolhas após o resultado

**Objetivo:** permitir que o jogador decida o que fazer depois de vencer ou perder.
**Alterar:** remover as transições automáticas das telas de resultado e substituí-las por botões persistentes.
**Não alterar:** condições de vitória e derrota, desbloqueio sequencial, dinheiro inicial, waves, torres ou trajetórias.
**Aceitação:**
- Dada uma derrota, o painel oferece somente recomeçar a fase ou voltar ao menu.
- Dada uma vitória antes da última fase, o painel oferece repetir, voltar ao menu ou iniciar diretamente a próxima fase desbloqueada.
- Dada uma vitória na última fase disponível, o botão **Próxima fase** aparece desativado.
- Enquanto nenhuma ação for escolhida, mapa, inimigos, torres, projéteis e waves permanecem congelados.

### Mudança: pausa pelo menu da partida

**Objetivo:** permitir interromper e retomar a partida com segurança pelo botão de três traços.
**Alterar:** ao abrir o menu ou as configurações durante uma partida, congelar toda a simulação e compensar os cronômetros pelo tempo pausado.
**Não alterar:** música escolhida, volumes, economia, progressão, posições e atributos existentes antes da pausa.
**Aceitação:**
- Inimigos, torres e projéteis não se movem nem atacam enquanto o menu está aberto.
- Waves, avisos, ataques e telas de vitória ou derrota não avançam durante a pausa.
- Fechar o menu retoma a partida do mesmo ponto, sem disparos ou inimigos atrasados surgirem imediatamente.
- Abrir **Configurações** pelo menu mantém a pausa até o painel ser fechado.
- Confirmar **Desistir** não conclui a fase nem desbloqueia a próxima, mas concede os Fragmentos correspondentes às waves alcançadas.

### Mudança: confirmação ao desistir

**Objetivo:** permitir sair voluntariamente da partida sem perder os Fragmentos conquistados pelas waves.
**Alterar:** substituir **Voltar ao lobby** por **Desistir** no menu da partida e exigir confirmação antes de sair.
**Não alterar:** cálculo de recompensa dos modos normal e infinito, pausa, progressão sequencial, boosts ou vinheta de retorno ao lobby.
**Aceitação:**
- Clicar em **Desistir** mantém a partida pausada e abre uma mensagem com a wave atual e a recompensa calculada.
- Desistir ou perder na wave 1 informa 0 Fragmentos; a recompensa normal começa na wave 2 com 2 Fragmentos.
- Na campanha normal, desistir na wave 6 informa e concede 6 Fragmentos.
- No modo infinito, desistir na wave 6 informa e concede 3 Fragmentos.
- Confirmar **Desistir** concede a recompensa uma única vez, limpa a partida atual e volta ao lobby.
- Clicar em **Nunca!** ou pressionar `Esc` não concede Fragmentos, fecha a confirmação e retorna ao menu pausado da fase.

## Áudio

- O lobby usa uma composição procedural exclusiva, calma e pixelada, com ganho relativo de 125%, melodia em onda quadrada, harmonia, baixo e percussão sintetizados pelo navegador; essa composição não toca durante nenhuma fase.
- A reprodução da música exclusiva é tentada automaticamente assim que o carregamento da página termina, sem exigir o clique em um botão do menu.
- Se a política de autoplay do navegador bloquear áudio audível, o jogo tenta liberá-lo na primeira interação em qualquer lugar da página e remove essa escuta assim que a música começa.
- A Fase 1 usa `background_music.mp3` durante a partida e acrescenta uma camada procedural chiptune contínua, com melodia em tonalidade menor, baixo grave e percussão abafada, preservando o clima defensivo da composição original.
- A camada pixelada da Fase 1 toca em passos de 360 ms com ganho relativo de 125%, enquanto `background_music.mp3` fica em 65% do volume escolhido durante essa fase; a parte chiptune recebe um leve destaque sem encobrir a composição original.
- O controle de volume e o botão de silenciar ajustam as duas partes em conjunto; ao voltar ao lobby ou entrar em outra fase, a camada pixelada é encerrada e `background_music.mp3` recupera 100% do volume escolhido.
- A Fase 2 substitui essa música por uma composição procedural retrô inspirada em sonoridade egípcia, baseada em escala frígia dominante, com melodia, bordão grave e percussão sintetizados pelo navegador.
- A Fase 3 substitui o arquivo de fundo por uma composição procedural exclusiva do Ártico, com melodia cristalina, sinos agudos, baixo suave e vento sintetizados pelo navegador.
- A Fase 4 substitui o arquivo de fundo por uma composição procedural exclusiva de selva, com melodia sombria pixelada, baixo grave, tambores sintetizados e pequenas chamadas agudas.
- A Fase 5 substitui o arquivo de fundo por uma composição procedural exclusiva do Bosque do Crepúsculo, com melodia misteriosa, harmonia pixelada, baixo suave e ruído de folhas sintetizados pelo navegador.
- A Fase 6 substitui o arquivo de fundo por uma composição procedural exclusiva da Forja Vulcânica, com melodia grave, ondas serrilhadas, baixo distorcido e percussão sintetizada.
- A Fase 7 substitui o arquivo de fundo por uma composição procedural exclusiva do Pântano Tóxico, com melodia úmida e misteriosa, baixo profundo, gotas e percussão abafada sintetizados.
- A Dimensão Glitch substitui o arquivo de fundo por uma composição procedural misteriosa e corrompida, com melodia desafinada, baixo grave, cortes digitais e ruídos curtos sintetizados.
- A trilha da selva toca em passos de 260 ms e usa ganho relativo de 145%, equilibrado com as demais músicas da campanha.
- A trilha da Fase 2 usa ganho relativo de 165%, além de melodia, baixo e percussão reforçados, para compensar a diferença de volume percebido em relação ao arquivo de música da Fase 1.
- Ao sair de qualquer fase, todas as trilhas da partida são encerradas antes de a música exclusiva do lobby começar; ao iniciar qualquer fase, a música do lobby é encerrada antes da trilha da partida.
- A música pode ser silenciada ou ativada no painel de configurações compartilhado entre lobby e partida.
- O volume da música pode ser ajustado de 0% a 100% nesse painel compartilhado.
- O volume e o botão de silenciar controlam a música exclusiva do lobby, `background_music.mp3`, a camada pixelada da Fase 1, todas as trilhas procedurais das Fases 2 a 7 e a trilha da Dimensão Glitch.
- A trilha da Fase 3 toca em passos de 400 ms com ganho relativo de 155% e usa `background_music.mp3` como alternativa quando Web Audio não está disponível.
- A trilha da Fase 5 toca em passos de 330 ms com ganho relativo de 165% e usa `background_music.mp3` como alternativa quando Web Audio não está disponível.
- A trilha da Fase 6 toca em passos de 240 ms com ganho relativo de 155% e usa `background_music.mp3` como alternativa quando Web Audio não está disponível.
- A trilha da Fase 7 toca em passos de 300 ms com ganho relativo de 160% e usa `background_music.mp3` como alternativa quando Web Audio não está disponível.
- O jogo possui efeitos sintetizados distintos para torre destruída pelo Sabotador, Game Over e vitória.
- O Rugido Ancestral usa o arquivo gravado sons/rugido-urso-ancestral.ogg, toca somente quando a habilidade do Urso Ancestral acerta ao menos uma torre e obedece ao volume e ao botão dos efeitos sonoros.
- A gravação “Bear growl”, de Shizhao, é usada sem alterações sob CC BY 3.0, com crédito e fonte registrados em sons/CREDITOS.md.
- Os efeitos começam em 80% de volume, acima dos 35% iniciais da música.
- O volume dos efeitos pode ser ajustado independentemente de 0% a 100%.
- O botão **Desativar efeitos** silencia apenas os efeitos sonoros; a música continua tocando.
- O botão **Ativar efeitos** restaura o último volume audível escolhido para os efeitos.
- Os efeitos sonoros continuam ativos quando somente a música é silenciada, e a música continua ativa quando somente os efeitos são silenciados.

### Mudança: música exclusiva da Fase 4

**Objetivo:** reforçar a identidade das Ruínas da Selva com uma trilha própria.
**Alterar:** substituir a música comum da Fase 4 por uma composição procedural tribal e pixelada que toca somente nessa fase.
**Não alterar:** música do lobby, trilhas das Fases 1 a 3, volume inicial, efeitos sonoros ou comportamento dos controles de áudio.
**Aceitação:**
- Ao iniciar a Fase 4, a música anterior para e a trilha da selva começa.
- A composição combina uma melodia em tonalidade menor, baixo, percussão tribal sintetizada e detalhes agudos, usando os valores centralizados no CONFIG.
- Silenciar, ativar ou ajustar o volume afeta a trilha da selva imediatamente.
- Ao voltar ao lobby ou iniciar outra fase, a trilha da selva é encerrada.
- Se o navegador não oferecer áudio procedural, a Fase 4 usa a música de fundo comum como alternativa.

## Interface visual

- A direção de arte pixelada e retrô aparece no lobby, no cenário do mapa e nos inimigos.
- Terreno, caminho, portões, barras de vida e decorações usam formas blocadas, contornos rígidos e cores chapadas.
- Torres, tiros e HUD mantêm acabamento suave para preservar a leitura das ações da partida.
- Marca GP, título da partida, status da zona, central da torre e botões externos ao mapa usam tipografia, bordas e sombras pixeladas.
- A Fase 1 possui árvores, pedras, arbustos, flores e lago pixelados como decorações não interativas.
- A Fase 2 usa tema de deserto, com areia quadriculada, caminho em tons de pedra, cactos, matos secos, rochas e pirâmides pixeladas.
- A Fase 3 usa tema ártico, com neve quadriculada, caminho de gelo, iglus, pinguins, pinheiros nevados, blocos de gelo e lago congelado pixelados.
- A Fase 4 usa tema de selva, com vegetação quadriculada, caminho de terra, árvores densas, cipós, flores tropicais, lagos e ruínas pixeladas.
- A Fase 5 usa floresta temperada de outono, com terreno em verde-oliva, árvores alaranjadas, cogumelos, folhas, troncos caídos e pequenos lagos pixelados.
- A Fase 6 usa uma forja vulcânica, com basalto quadriculado, lava, vulcões, rochas e cristais de obsidiana pixelados.
- A Fase 7 usa um pântano tóxico, com lodo quadriculado, água venenosa, árvores retorcidas, juncos, bolhas e cogumelos luminosos pixelados.
- O fim da trajetória possui uma torre-base pixelada, com cores próprias para os sete temas da campanha.
- Os pinguins são decorações não interativas; não recebem dano nem alteram a trajetória.
- Os cinco inimigos do elenco da Fase 1 possuem desenhos pixelados próprios: Vermelho, Roxo, Ciano rápido, Sabotador e Boss comum.
- O Sabotador mantém seus projéteis pixelados próprios e aparece nas sete fases.
- Escorpiões, Múmias e o Faraó de Areia possuem desenhos pixelados próprios e aparecem somente no mapa de deserto.
- Lobos de Gelo, Yetis e o Titã Glacial possuem desenhos pixelados próprios e aparecem somente no mapa ártico.
- Macacos Saqueadores, Onças da Selva, Gorilas da Selva e o Colosso da Selva possuem desenhos pixelados próprios e aparecem somente no mapa de selva.
- Raposas Ladinas, Javalis Furiosos, Corujas Sombrias e o Urso Ancestral possuem desenhos pixelados próprios e aparecem somente no Bosque do Crepúsculo.
- Morcegos de Fogo, Lagartos Vulcânicos, Golems de Magma, Fragmentos de Magma e o Titã de Obsidiana possuem desenhos pixelados próprios e aparecem somente na Forja Vulcânica.
- Mosquitos do Brejo, Sapos Venenosos, Guardiões de Lodo e a Hidra do Pântano possuem desenhos pixelados próprios e aparecem somente no Pântano Tóxico.
- As decorações das sete fases não bloqueiam torres nem alteram regras.
- O lobby acompanha imediatamente o tema da fase selecionada.
- Com a Fase 1 selecionada, o lobby usa gramado verde, lago, árvores, pedras e flores.
- Com a Fase 2 selecionada, o lobby usa areia quadriculada, painel em tons terrosos, cactos, matos secos e pirâmides.
- Com a Fase 3 selecionada, o lobby usa neve quadriculada, painel azul-gelo, iglus, pinguins, pinheiros nevados e blocos de gelo.
- Com a Fase 4 selecionada, o lobby usa vegetação quadriculada, painel verde-musgo, ruínas, árvores densas, cipós e flores tropicais.
- Com a Fase 5 selecionada, o lobby usa terreno verde-oliva, painel marrom, árvores outonais, cogumelos, folhas e troncos pixelados.
- Com a Fase 6 selecionada, o lobby usa basalto escuro, painel vermelho-obsidiana, vulcões, lava e cristais pixelados.
- Com a Fase 7 selecionada, o lobby usa lodo verde-escuro, painel musgo, árvores retorcidas, poças tóxicas, juncos e cogumelos luminosos.
- O caminho percorrido pelos inimigos aparece somente durante a partida.
- **Começar partida** permanece como o botão verde de maior destaque, acompanhado por **Álbum**, **Fases** e **Como jogar** na fileira principal.
- O atalho de **Configurações** fica no topo direito do lobby e concentra os controles de música, efeitos, iluminação e idioma.
- O rodapé do lobby resume créditos iniciais, limite de torres e as 20 waves de cada fase.
- O canto inferior direito do lobby exibe o crédito **Criado por Lequ48** com estilo pixelado e cores adaptadas ao tema selecionado.
- A chamada abaixo do título principal do lobby exibe **Sobreviva até o fim!**.
- Fases, Álbum e Como jogar são exibidos em um painel abaixo das ações e podem ser fechados sem iniciar a partida.
- Os cartões coletados do Álbum reutilizam os mesmos desenhos exibidos no mapa. Cada torre obtida mostra os visuais dos níveis 0 a 3; inimigos comuns, especiais e Bosses aparecem somente depois da primeira derrota daquele tipo.
- Durante a partida, o mapa é apresentado dentro de uma moldura com cabeçalho, seletor vertical de torres à direita e barra de ações inferior responsivos.
- O painel lateral direito permite escolher entre as seis torres de combate da campanha, incluindo o **Obliterador**, além das defesas especiais compradas na Loja. As torres da campanha são liberadas permanentemente pelo progresso; itens especiais são comprados na Loja.
- O tipo de torre selecionado recebe destaque visual e aparece no HUD com seu custo.
- O HUD exibe wave, dinheiro, quantidade de torres, custo de uma nova torre e recompensa por tiro.
- Quando uma torre está selecionada, o HUD e a barra inferior mostram seus atributos e as opções de melhorar e vender.
- Enquanto houver um inimigo dentro do alcance, o armamento da torre gira continuamente para mirar na posição desse alvo; a base permanece parada.
- A barra inferior possui um botão de prioridade para a torre selecionada, alternando entre **Primeiro**, **Último** e **Aleatório**.
- Avisos, Boss e Game Over possuem destaque visual próprio, sem alterar duração ou comportamento.
- Ao passar o mouse sobre um inimigo durante a partida, um tooltip pixelado exibe seu nome e sua vida atual/máxima.
- A apresentação visual não altera regras, valores de balanceamento nem condições de vitória ou derrota.

### Mudança: categorias do Álbum

**Objetivo:** transformar a consulta em um Álbum de Figurinhas que cresce conforme o jogador obtém defesas e derrota novos inimigos.
**Alterar:** manter as abas **Torres**, **Inimigos**, **Bosses**, **Minas** e **Skins**, mas ocultar itens ainda não obtidos e registrar a primeira derrota de cada tipo de inimigo.
**Não alterar:** atributos, regras de desbloqueio, recompensas, equipamentos, balanceamento, sprites, progresso das fases, Fragmentos, compras, conquistas, missões, pacote apoiador, preferências ou funcionamento das partidas.
**Aceitação:**
- **Torres** abre por padrão; a Torre padrão aparece desde o início e as demais torres, suportes e estruturas aparecem somente quando forem desbloqueados pela campanha ou comprados na Loja.
- Uma torre obtida mostra suas figurinhas dos níveis 0 a 3; torres não obtidas não revelam nome, desenho ou atributos.
- **Inimigos** mostra somente os tipos comuns e especiais que o jogador já derrotou, sem misturar Bosses.
- **Bosses** mostra somente os chefes já derrotados, em ordem de campanha.
- **Minas** mostra somente Mina Terrestre, Mina Congelante e Bomba Pesada que já tenham sido compradas na Loja.
- **Skins** mostra somente o Visual original e as skins já obtidas; visuais ainda bloqueados não aparecem.
- A primeira eliminação de cada tipo registra sua figurinha na chave local `guardians-of-pixel-album-figurinhas-v1`; eliminações seguintes do mesmo tipo não duplicam a figurinha.
- O histórico de figurinhas de inimigos começa vazio nesta versão para permitir testar a descoberta desde o começo.
- Esse início vazio não apaga nem altera estatísticas permanentes de eliminações, conquistas, progresso semanal, progresso das fases, Fragmentos, compras, skins, pacote apoiador, idioma ou preferências da conta.
- Categorias sem itens obtidos mostram apenas um espaço genérico com `?` e uma orientação de como conquistar a primeira figurinha, sem revelar unidades bloqueadas.
- Cada aba e o cabeçalho da página mostram a quantidade obtida e o total possível da categoria.
- A página usa aparência de caderno de figurinhas, com papel quadriculado, espiral, cartões claros e bordas recortadas, sem substituir os sprites existentes.
- Inimigos da Dimensão Glitch continuam ausentes até o portal ser descoberto e só ganham figurinha depois de derrotados.
- Trocar de categoria atualiza somente o painel do Álbum e reutiliza os mesmos desenhos do mapa.
- As cinco categorias, descrições, quantidades e estados acompanham português, inglês e espanhol.
- Em telas estreitas, as abas podem ser percorridas horizontalmente sem comprimir os cartões.

### Mudança: remake dos inimigos da Fase 1

**Objetivo:** substituir as formas simples do elenco inicial por unidades pixeladas mais reconhecíveis entre si.
**Alterar:** somente os desenhos de Vermelho, Roxo, Ciano rápido, Sabotador e Boss comum.
**Não alterar:** nomes, tipos internos, vida, velocidade, tamanho lógico, hitboxes, comportamentos, ataques, recompensas, ordem ou quantidade nas waves.
**Aceitação:**
- O Vermelho usa capacete, visor dourado, ombreiras, peitoral e botas.
- O Roxo parece um guarda pesado, com armadura larga, capacete reforçado e núcleo violeta.
- O Ciano rápido parece um corredor tecnológico leve, com aletas laterais e rastros de energia.
- O Sabotador parece um agente equipado, com capuz, visor vermelho, mochila, antena e arma lateral.
- O Boss comum parece um comandante blindado, com ombreiras grandes, elmo, olhos luminosos e núcleo dourado.
- O mapa e o Álbum reutilizam os mesmos cinco desenhos.
- Vida, velocidade, tamanho lógico e comportamento de todos os cinco inimigos permanecem iguais aos valores anteriores.
- Os inimigos exclusivos das Fases 2 a 7 não têm seus desenhos alterados nesta mudança.

### Mudança: escala visual do Ciano rápido e do Sabotador

**Objetivo:** aproximar o tamanho aparente dos dois inimigos ao tamanho do Vermelho sem alterar o balanceamento.
**Alterar:** usar escala visual 20 para o Ciano rápido e 22 para o Sabotador; o Vermelho usa 20 como referência.
**Não alterar:** tamanhos lógicos de 18 e 21, hitboxes, vida, velocidade, ataque, alcance ou composição das waves.
**Aceitação:**
- O Ciano rápido aparece com aproximadamente o mesmo tamanho do Vermelho no mapa e no Álbum.
- O Sabotador aparece levemente maior que o Vermelho por causa de seu equipamento.
- Detecção de acertos, colisões e posicionamento continuam usando os tamanhos lógicos originais.

### Mudança: cogumelos autorais no lobby da Fase 5

**Objetivo:** substituir os cogumelos genéricos do lobby por versões maiores baseadas nos dois desenhos pixelados criados para o Bosque do Crepúsculo.
**Alterar:** redesenhar somente os dois cogumelos decorativos do tema temperado com grade ampliada, contornos em degraus, manchas, luz e sombra.
**Não alterar:** cogumelos do mapa, Torre de Esporos, decorações das outras fases, mecânicas, balanceamento ou posição do painel central.
**Aceitação:**
- Com a Fase 5 selecionada, o lobby mostra um cogumelo vermelho com manchas claras e um cogumelo salmão com manchas escuras.
- Os dois desenhos preservam as silhuetas da referência autoral, usam pixels maiores e permanecem nítidos ao redimensionar a tela.
- Os cogumelos usam escala visual de 30% do desenho-base, resultando em aproximadamente 36 a 54 px, próximos ao tamanho dos cogumelos antigos e menores que as árvores outonais.
- Nas Fases 1 a 4, os dois cogumelos continuam ocultos junto das demais decorações temperadas.

### Mudança: decorações centrais nos temas do lobby

**Objetivo:** preencher a área central do cenário sem prejudicar a leitura ou a interação com o menu.
**Alterar:** reutilizar três desenhos pixelados de cada tema na faixa central do lobby, com opacidade de 72% em telas largas e 46% em telas de até 760 px.
**Não alterar:** seleção e desbloqueio das fases, funcionamento dos botões, desenhos existentes nas bordas ou temas das partidas.
**Aceitação:**
- Campo, deserto, Ártico, selva e floresta temperada exibem exatamente três decorações adicionais distribuídas entre 29% e 70% da largura do cenário.
- As novas decorações ficam na camada de cenário, atrás do cartão do menu e sem capturar cliques.
- Em telas de até 760 px, as decorações centrais permanecem presentes com opacidade reduzida para não competir com o conteúdo.
- Os cogumelos autorais da Fase 5 usam escala de 30% e continuam visíveis somente no tema temperado.

### Mudança: árvore autoral no lobby da Fase 1

**Objetivo:** substituir o desenho genérico das árvores do campo pela pixel art criada pelo autor.
**Alterar:** usar o sprite transparente **assets/arvore-campo-lobby.png**, com 423 × 572 px, nas quatro árvores já posicionadas no lobby da Fase 1; o tamanho-base exibido é 74 × 100 px.
**Não alterar:** posições e escalas individuais das árvores, demais decorações, temas das Fases 2 a 5, mapa da partida ou funcionamento do menu.
**Aceitação:**
- A imagem aparece sem o fundo pêssego, sem halo pêssego nas bordas e sem a faixa escura do aplicativo de desenho.
- As três árvores das bordas e a árvore central reutilizam o mesmo sprite com renderização pixelada.
- Ao selecionar as Fases 2 a 5, as árvores do campo continuam ocultas pelas regras existentes de cada tema.
- Nenhum elemento novo captura cliques ou altera a seleção das fases.

### Mudança: cenário vivo do lobby da Fase 1

**Objetivo:** harmonizar o campo com a árvore autoral e tornar o cenário mais vivo sem reduzir a legibilidade do menu.
**Alterar:** usar gramado quadriculado em **#3F7F3D** e **#326B35**, detalhes baseados na paleta da árvore e acrescentar dois arbustos e três tufos de grama pixelados.
**Não alterar:** painel e botões do lobby, posições das árvores, temas das Fases 2 a 5, mapa da partida, progressão ou balanceamento.
**Aceitação:**
- O lago usa água ciano clara, brilho suave e borda verde **#3CA370**.
- Pedras têm contorno mais fino e tons quentes; flores usam **#CFFF70**, **#BA6156** e **#3CA370**.
- As sombras das árvores e decorações ficam mais leves que as antigas.
- Durante o dia, árvores, lago, pedras, flores, arbustos e tufos de grama usam 68% do brilho, 82% da saturação e um leve reforço de contraste, deixando o escurecimento claramente perceptível sem afetar a interface.
- Os dois arbustos e três tufos aparecem somente quando a Fase 1 está selecionada e permanecem atrás da interface.
- Em telas de até 760 px, arbustos e tufos usam 62% de opacidade para não competir com os controles.
- O filtro mais escuro do modo noturno continua prevalecendo sobre o ajuste diurno, sem trocar as cores-base do tema.
- Os cogumelos permanecem atrás da interface e não recebem cliques nem alteram a partida.

### Mudança: seletor vertical de torres

**Objetivo:** impedir que novas armas ocupem o espaço dos controles de melhorar e vender.
**Alterar:** mover somente os botões de construção para um painel vertical e rolável encostado à direita do mapa, sem espaço entre o mapa e o painel.
**Não alterar:** posição inferior dos botões **Melhorar torre** e **Vender torre**, atalhos E e X, custos, desbloqueios ou regras de construção.
**Aceitação:**
- Cada tipo de torre ocupa uma linha própria no painel direito.
- A borda direita do mapa toca diretamente o painel de torres, formando uma única área de jogo.
- Quando a proporção da tela deixa uma faixa livre à esquerda do mapa, ela exibe um posto de comando pixelado atrás do canvas sem reduzir sua área.
- Se novos tipos ultrapassarem a altura disponível, apenas a lista de torres recebe rolagem vertical.
- Os botões de melhorar e vender permanecem na barra inferior.
- O painel lateral aparece somente durante a partida e mantém um formato compacto em telas menores.

### Mudança: mira dinâmica das torres

**Objetivo:** fazer os disparos parecerem conectados ao alvo acompanhado pela torre.
**Alterar:** girar somente o armamento de cada torre para apontar para o alvo escolhido dentro do alcance.
**Não alterar:** alcance, cadência, dano, velocidade dos projéteis ou comportamento das melhorias.
**Aceitação:**
- Com um inimigo no alcance, o canhão, o cristal ou a Besta aponta para a posição atual dele mesmo durante o intervalo entre tiros.
- A base circular da torre não gira.
- Sem inimigos no alcance, a torre mantém a última direção observada.
- As miniaturas do Álbum continuam usando a direção frontal padrão.

### Mudança: prioridade de alvo por torre

**Objetivo:** permitir que o jogador escolha como cada torre distribui seus disparos.
**Alterar:** adicionar um botão único na barra inferior que alterna a prioridade da torre selecionada na ordem **Primeiro**, **Último** e **Aleatório**.
**Não alterar:** alcance, dano, cadência, velocidade do projétil, escolha de alvo dos inimigos ou controles de melhorar e vender.
**Aceitação:**
- Cada torre nova começa no modo **Primeiro**.
- **Primeiro** escolhe, entre os inimigos no alcance, o que percorreu a maior distância em direção à base.
- **Último** escolhe, entre os inimigos no alcance, o que percorreu a menor distância desde a entrada.
- **Aleatório** escolhe um inimigo no alcance a cada novo disparo e mantém a mira nele durante a recarga.
- Cada torre guarda sua própria prioridade; alterar uma torre não modifica as demais.
- Sem uma torre selecionada, o botão permanece desabilitado.

### Mudança: informações do inimigo ao passar o mouse

**Objetivo:** permitir que o jogador identifique cada inimigo sem precisar abrir o Álbum.
**Alterar:** detectar o inimigo sob o ponteiro no canvas e desenhar um tooltip pixelado próximo ao cursor.
**Não alterar:** movimento, vida, dano, seleção e construção de torres ou comportamento das waves.
**Aceitação:**
- O tooltip mostra o nome configurado do inimigo e sua vida atual/máxima.
- A posição do ponteiro é convertida corretamente mesmo quando o canvas está redimensionado.
- O tooltip acompanha inimigos em movimento e permanece dentro dos limites do mapa.
- Ao retirar o ponteiro do mapa ou do inimigo, o tooltip desaparece.

## Regras atuais

| Área | Regra |
| --- | --- |
| Dinheiro inicial | 150 |
| Custo da Torre padrão | 150 |
| Custo do Canhão pesado | 250 |
| Desbloqueio do Canhão pesado | Concluir a Fase 1; depois fica disponível em todas as fases |
| Custo da Torre Glacial | 350 |
| Desbloqueio da Torre Glacial | Concluir a Fase 2; depois fica disponível em todas as fases atuais e futuras |
| Custo da Torre Besta | 400 |
| Desbloqueio da Torre Besta | Concluir a Fase 3; depois fica disponível em todas as fases atuais e futuras |
| Custo da Torre de Esporos | 475 |
| Desbloqueio da Torre de Esporos | Concluir a Fase 4; depois fica disponível em todas as fases |
| Custo do Obliterador | 550 |
| Desbloqueio do Obliterador | Concluir a Fase 5; depois fica disponível em todas as fases |
| Fragmentos de Pixel iniciais | 0 |
| Recompensa ao encerrar uma partida normal | Wave 1 concede 0; da wave 2 em diante, a recompensa é igual à wave alcançada |
| Recompensa no modo Waves infinitas | 1 Fragmento de Pixel a cada 2 waves alcançadas, arredondado para baixo |
| Preço da Isca Blindada na Loja | 30 Fragmentos de Pixel |
| Custo da Isca Blindada na partida | 200 |
| Resistência da Isca Blindada | 10 impactos de inimigos atiradores |
| Limite de Iscas Blindadas | 2 por partida, dentro do limite total de torres da fase |
| Preço do Amplificador Pixel na Loja | 45 Fragmentos de Pixel |
| Custo do Amplificador Pixel na partida | 300 |
| Alcance do Amplificador Pixel | 135 px |
| Bônus do Amplificador Pixel | Reduz em 15% o intervalo de ataque das torres de combate próximas |
| Limite de Amplificadores Pixel | 1 por partida, dentro do limite total de torres da fase |
| Preço da Mina Terrestre na Loja | 25 Fragmentos de Pixel |
| Custo da Mina Terrestre na partida | 100 |
| Dano da Mina Terrestre | 100 em uma área de 75 px |
| Contato da Mina Terrestre | Explode somente quando um inimigo encosta no raio físico de 18 px |
| Limite de Minas Terrestres | 5 armadas ao mesmo tempo, fora do limite total de torres |
| Preço da Bomba Pesada na Loja | 40 Fragmentos de Pixel |
| Custo da Bomba Pesada na partida | 200 |
| Dano da Bomba Pesada | 200 em uma área de 100 px |
| Detonação da Bomba Pesada | Manual; clique acende um pavio irrevogável de 1,5 segundo |
| Limite de Bombas Pesadas | 3 posicionadas ao mesmo tempo, fora do limite total de torres |
| Torre de Raios | 60 Fragmentos; 425 créditos; 30 de dano; salta por até 3 alvos a 110 px |
| Lança-Chamas | 100 Fragmentos; 650 créditos; 10 de dano; ataque a cada 333 ms; queimadura de 5 por segundo durante 10 s |
| Mina Congelante | 35 Fragmentos; 125 créditos; 55 de dano em 85 px; 50% de lentidão por 2.500 ms |
| Reserva de Créditos | 30 Fragmentos; aumenta os créditos iniciais de 150 para 200 |
| Licença de Construção | 45 Fragmentos; acrescenta 1 vaga ao limite de todas as fases |
| Recompensa Otimizada | 55 Fragmentos; aumenta a recompensa por tiro de 20 para 22 |
| Recompensa por tiro | 20; 22 após comprar Recompensa Otimizada |
| Limite de torres na Fase 1 | 10 |
| Limite de torres na Fase 2 | 12 |
| Limite de torres na Fase 3 | 12 |
| Limite de torres na Fase 4 | 14 |
| Limite de torres na Fase 5 | 16 |
| Limite de torres na Fase 6 | 18 |
| Limite de torres na Fase 7 | 20 |
| Dano da Torre padrão nível 0 | 10 |
| Alcance da Torre padrão nível 0 | 150 px |
| Ataque da Torre padrão nível 0 | 500 ms |
| Dano do Canhão pesado nível 0 | 20 |
| Alcance do Canhão pesado nível 0 | 110 px |
| Ataque do Canhão pesado nível 0 | 700 ms |
| Dano da Torre Glacial nível 0 | 18 |
| Alcance da Torre Glacial nível 0 | 170 px |
| Ataque da Torre Glacial nível 0 | 800 ms |
| Velocidade do estilhaço da Torre Glacial | 8 px por frame |
| Lentidão da Torre Glacial nível 0 | 25% por 1.400 ms |
| Congelamento da Torre Glacial nível 0 | 500 ms após 4 acertos; Bosses não congelam |
| Dano da Torre Besta nível 0 | 55 |
| Alcance da Torre Besta nível 0 | 210 px |
| Ataque da Torre Besta nível 0 | 1.100 ms |
| Velocidade do virote da Torre Besta | 10 px por frame |
| Dano da Torre de Esporos nível 0 | 42 em uma área de 60 px |
| Alcance da Torre de Esporos nível 0 | 185 px |
| Ataque da Torre de Esporos nível 0 | 1.050 ms |
| Velocidade do orbe da Torre de Esporos | 7,5 px por frame |
| Ataque do Obliterador nível 0 | 3 lasers de 48 de dano a cada 1.600 ms |
| Alcance do Obliterador nível 0 | 230 px |
| Velocidade dos lasers do Obliterador | 13 px por frame |
| Espaçamento mínimo entre torres | 70 px |
| Derrota pela torre-base | O primeiro inimigo que tocar a estrutura encerra imediatamente a partida |
| Vida do inimigo vermelho | 100 |
| Vida do inimigo roxo | 300 |
| Vida do inimigo rápido | 200 |
| Velocidade do inimigo rápido | 2,2 px por frame |
| Vida do Sabotador | 75 (75% da vida do vermelho) |
| Velocidade do Sabotador | 1,1 px por frame (igual ao roxo) |
| Alcance de ataque do Sabotador | 180 px |
| Intervalo de ataque do Sabotador | 1,2 s |
| Tiros para destruir uma torre | 6 |
| Vida do Escorpião do deserto | 160 |
| Velocidade do Escorpião do deserto | 1,9 px por frame |
| Vida da Múmia | 500 |
| Velocidade da Múmia | 0,85 px por frame |
| Vida do Lobo de Gelo | 240 |
| Velocidade do Lobo de Gelo | 1,8 px por frame |
| Vida do Yeti | 650 |
| Velocidade do Yeti | 0,75 px por frame |
| Vida do Macaco Saqueador | 220 |
| Velocidade do Macaco Saqueador | 2 px por frame |
| Ataque do Macaco Saqueador | Alcance de 165 px; 1 disparo a cada 1,8 s |
| Lentidão causada pelo Macaco | Aumenta o intervalo de ataque da torre em 25% por 2.500 ms |
| Vida da Onça da Selva | 360 |
| Velocidade da Onça da Selva | 1,7 px por frame |
| Disparada da Onça da Selva | +45% de velocidade ao ficar com 50% da vida ou menos |
| Vida do Gorila da Selva | 850 |
| Velocidade do Gorila da Selva | 0,6 px por frame |
| Vida da Raposa Ladina | 260 |
| Velocidade da Raposa Ladina | 2,55 px por frame |
| Vida do Javali Furioso | 950 |
| Velocidade do Javali Furioso | 0,72 px por frame |
| Arrancada do Javali Furioso | A cada 4 s, +80% de velocidade durante 1.100 ms |
| Vida da Coruja Sombria | 420 |
| Velocidade da Coruja Sombria | 1,4 px por frame |
| Ataque da Coruja Sombria | Alcance de 190 px; 1 disparo a cada 2,1 s |
| Enfraquecimento da Coruja | Reduz o alcance da torre em 25% por 3.000 ms |
| Vida base do Boss | 1.000 |
| Aumento de vida do Boss | +500 a cada aparição |
| Velocidade do Boss | 1,1 px por frame (igual ao roxo) |
| Vida base do Faraó de Areia | 2.000 |
| Aumento de vida do Faraó de Areia | +500 a cada aparição |
| Velocidade do Faraó de Areia | 1,3 px por frame (entre o roxo e o vermelho) |
| Vida base do Titã Glacial | 3.000 |
| Aumento de vida do Titã Glacial | +500 a cada aparição |
| Velocidade do Titã Glacial | 0,65 px por frame |
| Vida base do Colosso da Selva | 4.000 |
| Aumento de vida do Colosso da Selva | +500 a cada aparição |
| Velocidade do Colosso da Selva | 0,55 px por frame |
| Vida base do Urso Ancestral | 3.500 |
| Aumento de vida do Urso Ancestral | +500 a cada aparição |
| Velocidade do Urso Ancestral | 0,45 px por frame |
| Primeiro Rugido Ancestral | 3.500 ms depois do surgimento |
| Intervalo entre Rugidos Ancestrais | 6.000 ms |
| Raio do Rugido Ancestral | 230 px |
| Atordoamento do Rugido Ancestral | 1.400 ms |
| Vida do Morcego de Fogo | 280 |
| Velocidade do Morcego de Fogo | 2,8 px por frame |
| Vida do Lagarto Vulcânico | 480 |
| Velocidade do Lagarto Vulcânico | 1,65 px por frame |
| Vida do Golem de Magma | 1.100 |
| Velocidade do Golem de Magma | 0,68 px por frame |
| Vida do Fragmento de Magma | 180 |
| Velocidade do Fragmento de Magma | 2,5 px por frame |
| Vida do Titã de Obsidiana | 3.200 em todas as aparições |
| Velocidade do Titã de Obsidiana | 1,05 px por frame; 1,7325 após a erupção |
| Carapaça do Titã de Obsidiana | Reduz dano em 15% e impede a vida de atravessar 50% antes da transformação |
| Vida do Mosquito do Brejo | 340 |
| Velocidade do Mosquito do Brejo | 3 px por frame |
| Vida do Sapo Venenoso | 650 |
| Velocidade do Sapo Venenoso | 1,35 px por frame |
| Vida do Guardião de Lodo | 1.400 |
| Velocidade do Guardião de Lodo | 0,62 px por frame |
| Vida base da Hidra do Pântano | 3.800 |
| Aumento de vida da Hidra do Pântano | +500 a cada aparição |
| Velocidade da Hidra do Pântano | 0,7 px por frame |
| Regeneração da Hidra do Pântano | Ativa permanentemente ao alcançar 50% da vida e restaura 40 de vida por segundo, sem ultrapassar a vida máxima |
| Primeira wave com roxos | 5 |
| Última wave da campanha | 20 |
| Melhorias por torre de combate | 3 |

## Waves

- Na Fase 1, as waves 1 a 4 possuem apenas inimigos vermelhos; a wave contém `wave + 1` inimigos.
- A Fase 2 mantém toda a composição de inimigos da Fase 1 e acrescenta seus inimigos exclusivos.
- A Fase 3 usa a composição comum da Fase 1, incluindo Sabotadores, e acrescenta Lobos de Gelo, Yetis e o Titã Glacial sem incluir Escorpiões, Múmias, Faraó de Areia ou Boss vinho.
- A Fase 4 usa a composição comum da Fase 1, incluindo Sabotadores, e acrescenta Macacos Saqueadores, Onças da Selva, Gorilas da Selva e o Colosso da Selva sem incluir inimigos exclusivos das fases anteriores.
- A Fase 5 usa a composição comum da Fase 1, incluindo Sabotadores, e acrescenta Raposas Ladinas, Javalis Furiosos, Corujas Sombrias e o Urso Ancestral sem incluir inimigos exclusivos das fases anteriores.
- A Fase 6 usa a composição comum da Fase 1, incluindo Sabotadores, e acrescenta Morcegos de Fogo, Lagartos Vulcânicos, Golems de Magma e o Titã de Obsidiana sem incluir inimigos exclusivos das fases anteriores.
- A Fase 7 usa a composição comum da Fase 1, incluindo Sabotadores, e acrescenta Mosquitos do Brejo, Sapos Venenosos, Guardiões de Lodo e a Hidra do Pântano sem incluir inimigos exclusivos das fases anteriores.
- Wave 5: 2 inimigos roxos.
- A partir da wave 6, os inimigos vermelhos crescem de 0 até 3 enquanto os roxos permanecem iguais.
- Depois de uma wave com 3 vermelhos, a próxima zera os vermelhos e adiciona 1 inimigo roxo.
- Exemplos: wave 8 = 2 roxos + 3 vermelhos; wave 9 = 3 roxos; wave 12 = 3 roxos + 3 vermelhos; wave 13 = 4 roxos.
- Todas as waves a partir da 5 recebem inimigos rápidos cianos: 1 rápido com 2 roxos, 2 rápidos com 3 roxos, 3 rápidos com 4 roxos, e assim por diante. A presença de vermelhos não altera essa quantidade.
- O Sabotador aparece nas sete fases a partir da wave 6: 1 unidade nas waves 6 a 10, 2 nas waves 11 a 15 e 3 nas waves 16 a 20.
- Na Fase 1, toda wave múltipla de 5 até a wave 20 inclui 1 Boss vinho. Sua vida começa em 1.000 na wave 5 e aumenta 500 a cada nova aparição.

| Wave | Vida do Boss |
| --- | --- |
| 5 | 1.000 |
| 10 | 1.500 |
| 15 | 2.000 |
| 20 | 2.500 |

- Na Fase 2, o Faraó de Areia substitui o Boss vinho nas waves 5, 10, 15 e 20. Sua vida começa em 2.000 e aumenta 500 a cada aparição.

| Wave | Vida do Faraó de Areia |
| --- | --- |
| 5 | 2.000 |
| 10 | 2.500 |
| 15 | 3.000 |
| 20 | 3.500 |

- Na Fase 3, o Titã Glacial substitui o Boss vinho nas waves 5, 10, 15 e 20. Sua vida começa em 3.000 e aumenta 500 a cada aparição.

| Wave | Vida do Titã Glacial |
| --- | --- |
| 5 | 3.000 |
| 10 | 3.500 |
| 15 | 4.000 |
| 20 | 4.500 |

- Na Fase 4, o Colosso da Selva substitui o Boss vinho nas waves 5, 10, 15 e 20. Sua vida começa em 4.000 e aumenta 500 a cada aparição.

| Wave | Vida do Colosso da Selva |
| --- | --- |
| 5 | 4.000 |
| 10 | 4.500 |
| 15 | 5.000 |
| 20 | 5.500 |

- Na Fase 5, o Urso Ancestral substitui o Boss vinho nas waves 5, 10, 15 e 20. Sua vida começa em 3.500 e aumenta 500 a cada aparição.
- Na Fase 6, o Titã de Obsidiana substitui os demais Bosses nas waves 5, 10, 15 e 20. Sua vida permanece em 3.200; a quantidade de Fragmentos de Magma liberados na transformação cresce de 2 até 5.
- Na Fase 7, a Hidra do Pântano substitui os demais Bosses nas waves 5, 10, 15 e 20. Sua vida começa em 3.800, aumenta 500 por aparição e sua regeneração permanente é ativada ao alcançar 50% da vida.

| Wave | Vida do Urso Ancestral |
| --- | --- |
| 5 | 3.500 |
| 10 | 4.000 |
| 15 | 4.500 |
| 20 | 5.000 |

- Ao iniciar uma wave com chefe, o aviso mostra **ALGO ESTÁ VINDO...** e destaca **BOSS**, **FARAÓ**, **TITÃ**, **COLOSSO**, **URSO**, **OBSIDIANO** ou **HIDRA** conforme a fase, por 2,5 segundos.
- Há 700 ms entre o surgimento de inimigos e 2 s entre waves concluídas.

### Modo Waves infinitas

- O botão **Waves infinitas** usa a fase selecionada no lobby e respeita seu desbloqueio, tema, trajetória, inimigos exclusivos e limite de torres.
- As waves continuam depois da wave 20 usando as mesmas fórmulas de crescimento de inimigos e de vida dos Bosses.
- Bosses continuam surgindo a cada 5 waves e recebem mais 500 de vida a cada aparição.
- O modo não mostra vitória, não conclui fases nem desbloqueia a fase seguinte; quando a base é invadida, concede 1 Fragmento de Pixel a cada 2 waves alcançadas.
- Waves ímpares não completam o próximo par: terminar na wave 21 concede 10 Fragmentos, enquanto terminar na wave 22 concede 11.
- A partida termina somente quando um inimigo invade a torre-base.
- **Reiniciar fase** e **Recomeçar fase** preservam o modo infinito; voltar ao lobby encerra o modo.
- Os bônus pós-Boss continuam restritos às waves configuradas da campanha e o fliperama mantém suas waves atuais.

### Bônus pós-Boss

- Depois que todos os inimigos das waves 5, 10 e 15 forem derrotados, a partida pausa e apresenta 3 opções aleatórias entre 4 bônus.
- O jogador deve escolher 1 bônus para continuar; a opção escolhida permanece ativa até o fim da partida.
- Bônus de atributos afetam todas as torres construídas e também as torres que forem construídas ou melhoradas depois da escolha.
- Bônus iguais podem aparecer e acumular em escolhas futuras da mesma partida.
- **Cadência rápida:** reduz em 10% o intervalo entre ataques de todas as torres.
- **Suprimentos:** entrega 300 créditos imediatamente.
- **Munição reforçada:** aumenta em 10% o dano de todas as torres.
- **Mira ampliada:** aumenta em 8% o alcance de todas as torres.
- O posto do lado esquerdo do mapa lista todos os bônus escolhidos na partida, agrupa escolhas repetidas e mostra o efeito acumulado de cada tipo.
- **Suprimentos** permanece registrado no posto como histórico da recompensa recebida.
- A wave 20 encerra a partida com vitória depois que todos os inimigos forem derrotados e não oferece bônus.

#### Mudança: escolha de recompensa após Boss

**Objetivo:** criar decisões diferentes durante a partida e reduzir a repetição entre waves.
**Alterar:** interromper o intervalo normal após as waves de Boss 5, 10 e 15 para oferecer 3 bônus aleatórios.
**Não alterar:** composição das waves, vida e velocidade dos inimigos, aparição dos Bosses, custos das torres ou condição de vitória.
**Aceitação:**
- Enquanto a escolha estiver aberta, inimigos, torres, tiros e cronômetros permanecem pausados.
- Somente uma das três opções pode ser escolhida em cada aparição.
- Depois da escolha, o painel fecha, o bônus é aplicado e a contagem para a próxima wave continua.
- Reiniciar ou abandonar a fase remove todos os bônus daquela partida.

### Evento do Fliperama

- Um fliperama pixelado aparece em uma posição livre do mapa no início das waves 7 e 14 de todas as fases.
- O fliperama usa o sprite transparente **assets/fliperama-pixel.png**, renderizado sem suavização em 53 × 100 px; se o arquivo não puder ser carregado, o desenho pixelado anterior é usado como fallback.
- A posição não pode estar no caminho, sobre uma torre ou Bomba Pesada, próxima da torre-base ou fora da margem segura do mapa.
- O fliperama permanece disponível por 10 segundos. Se não for clicado, desaparece sem penalidade.
- Ao clicar no fliperama, a batalha e seus cronômetros pausam e um dos minigames **Tiro ao alvo** ou **Labirinto Pixel** é sorteado.
- Ambos os minigames duram 15 segundos.
- O **Tiro ao alvo** exige 10 acertos no mesmo alvo móvel.
- O alvo se desloca continuamente a 185 px por segundo, rebate nas quatro bordas e nunca troca de posição por teletransporte.
- Depois de cada acerto, o alvo muda sua direção sem alterar a posição e aguarda 140 ms antes de aceitar o próximo clique.
- Falhar ou deixar o tempo acabar apenas fecha o minigame e continua a partida.
- Concluir o **Tiro ao alvo** reduz em 20% o intervalo de ataque de todas as torres por 30 segundos.
- No **Labirinto Pixel**, um dos três mapas — **Zigue-zague**, **Corredores** ou **Espelho** — é sorteado a cada abertura.
- Nos três mapas, o robô é movido continuamente por **WASD** ou pelas setas; encostar em qualquer parede devolve o robô à posição inicial daquele mapa.
- Alcançar a saída do **Labirinto Pixel** aumenta em 15% o dano de todas as torres por 30 segundos.
- Os boosts afetam torres atuais, futuras e melhoradas, combinam de forma multiplicativa com os bônus pós-Boss correspondentes e não perdem duração enquanto a partida estiver pausada.
- A seção **Temporário** do posto possui somente uma entrada chamada **Fliperama**. Ela mostra o efeito de cadência, o efeito de dano ou ambos, com uma barra de duração para cada efeito ativo; **Labirinto** não aparece como boost separado.
- Concluir novamente o mesmo minigame enquanto seu boost ainda está ativo acrescenta mais 30 segundos à duração correspondente.

#### Mudança: novo sprite do fliperama

**Objetivo:** substituir a máquina desenhada por blocos por uma pixel art dedicada sem introduzir fundo xadrez ou falhas de carregamento.
**Alterar:** carregar o sprite transparente de 530 × 1000 px e desenhá-lo no mapa em 53 × 100 px, sem suavização.
**Não alterar:** waves 7 e 14, raio de clique de 46 px, posição livre, duração de 10 segundos, sorteio dos minigames, recompensas ou pausa da batalha.
**Aceitação:**
- O PNG carregado mostra somente a máquina, sem marca d'água, fundo verde ou padrão xadrez.
- O sprite mantém a proporção original, fica centralizado na posição do evento e desativa a suavização do canvas.
- Enquanto a imagem ainda carrega ou se ocorrer erro, o arcade anterior é desenhado e o evento continua clicável.
- A contagem **CLIQUE · Ns** permanece acima da máquina com o mesmo tempo disponível.

#### Mudança: minigame de tiro ao alvo

**Objetivo:** interromper a repetição das waves com um evento opcional de habilidade.
**Alterar:** criar um fliperama clicável nas waves 7 e 14 e recompensar a conclusão do minigame com cadência temporária.
**Não alterar:** composição das waves, custos, desbloqueios, limites de torres ou condições de vitória e derrota.
**Aceitação:**
- O fliperama nunca bloqueia o caminho e não permite construir uma torre sobre sua área.
- Enquanto o minigame estiver aberto, inimigos, torres, projéteis, waves e efeitos temporários permanecem pausados.
- Cada clique correto soma um ponto; cliques fora do alvo não causam penalidade.
- Durante todo o minigame, a posição do alvo é atualizada continuamente e permanece dentro da área visível.
- Ao alcançar 10 pontos antes de 15 segundos, o painel fecha, a batalha continua e o boost é aplicado.
- Ao reiniciar ou abandonar a fase, o minigame, o fliperama e o boost são removidos.

#### Mudança: Labirinto Pixel

**Objetivo:** adicionar uma segunda prova de habilidade ao fliperama para variar o ritmo das partidas.
**Alterar:** sortear entre o minigame de alvo existente e um labirinto controlado por teclado, que também sorteia um entre três mapas e mantém sua recompensa própria.
**Não alterar:** waves de aparição do fliperama, duração de 15 segundos, pausa da batalha, composição das waves ou o boost de cadência do Tiro ao alvo.
**Aceitação:**
- Cada clique válido no fliperama sorteia com a mesma lista de opções o **Tiro ao alvo** ou o **Labirinto Pixel**.
- Ao sortear o Labirinto Pixel, o jogo escolhe um mapa entre **Zigue-zague**, **Corredores** e **Espelho** e mostra seu nome no painel.
- Cada modelo possui início, saída e paredes próprios; todos oferecem uma rota possível até a saída dentro da mesma área de 720 × 420 px.
- O robô do Labirinto aceita **WASD** e setas, move-se continuamente enquanto a tecla estiver pressionada e permanece dentro do canvas.
- Encostar em uma das paredes reinicia somente a posição do robô; o cronômetro continua.
- Chegar à saída antes do fim dos 15 segundos fecha o painel, retoma a batalha e aplica +15% de dano durante 30 segundos.
- Falhar retoma a batalha sem bônus e sem penalidade adicional.
- O boost de dano aparece dentro da única entrada **Fliperama** do posto lateral, congela durante pausas e é removido ao reiniciar ou abandonar a fase.

### Posto de boosts

- O antigo posto de controle decorativo do lado esquerdo é o painel de boosts da partida.
- Antes da primeira escolha pós-Boss, o painel informa que ainda não há bônus.
- Cada bônus pós-Boss aparece com ícone, nome, efeito acumulado e quantidade de vezes escolhida.
- Bônus repetidos ocupam uma única linha e incrementam seu contador.
- O boost do fliperama fica separado dos bônus permanentes porque possui duração limitada.
- O posto não cria uma linha própria para cada minigame: **Tiro ao alvo** e **Labirinto Pixel** compartilham a única entrada temporária **Fliperama**.
- Quando cadência e dano estiverem ativos ao mesmo tempo, a entrada **Fliperama** mostra os dois tempos e duas barras internas.
- Quando o boost do fliperama está inativo, sua área permanece visível com o estado **Aguardando evento**.
- Reiniciar a fase limpa a lista de bônus e restaura o estado inativo do fliperama.

#### Mudança: painel lateral de efeitos

**Objetivo:** usar o espaço esquerdo do mapa para manter as recompensas da partida visíveis.
**Alterar:** substituir a decoração do posto de controle por uma lista dinâmica de bônus permanentes e temporários.
**Não alterar:** valores, duração, acumulação ou momento de oferta dos bônus.
**Aceitação:**
- Escolher um bônus pós-Boss atualiza o posto imediatamente.
- Escolhas repetidas exibem a quantidade e o efeito acumulado correto.
- O temporizador do fliperama não diminui visualmente enquanto a partida está pausada.
- O antigo indicador do fliperama deixa de ocupar a parte inferior do mapa.

### Inimigos exclusivos da Fase 2

- Escorpiões do deserto começam na wave 3 com 1 unidade e recebem mais 1 unidade a cada 4 waves.
- Quantidade de Escorpiões: waves 3 a 6 = 1; 7 a 10 = 2; 11 a 14 = 3; 15 a 18 = 4; 19 e 20 = 5.
- Múmias começam na wave 7 com 1 unidade e recebem mais 1 unidade a cada 5 waves.
- Quantidade de Múmias: waves 7 a 11 = 1; 12 a 16 = 2; 17 a 20 = 3.
- A wave 20 da Fase 2 contém 5 Escorpiões e 3 Múmias adicionais.
- Escorpiões e Múmias são somados aos inimigos vermelhos, roxos e rápidos existentes.
- O Faraó de Areia substitui o Boss comum nas waves em que aparece; os dois Bosses nunca aparecem juntos.
- Escorpiões, Múmias e o Faraó de Areia nunca são criados nas Fases 1, 3, 4 ou 5.

### Inimigos exclusivos da Fase 3

- Lobos de Gelo possuem 240 de vida e velocidade de 1,8 px por frame.
- Lobos de Gelo começam na wave 3 com 1 unidade e recebem mais 1 unidade a cada 4 waves.
- Quantidade de Lobos de Gelo: waves 3 a 6 = 1; 7 a 10 = 2; 11 a 14 = 3; 15 a 18 = 4; 19 e 20 = 5.
- Yetis possuem 650 de vida e velocidade de 0,75 px por frame.
- Yetis começam na wave 7 com 1 unidade e recebem mais 1 unidade a cada 5 waves.
- Quantidade de Yetis: waves 7 a 11 = 1; 12 a 16 = 2; 17 a 20 = 3.
- A wave 20 da Fase 3 contém 5 Lobos de Gelo e 3 Yetis adicionais.
- Lobos de Gelo e Yetis são somados aos inimigos comuns, Sabotadores e ao Titã Glacial.
- Lobos de Gelo e Yetis nunca são criados nas Fases 1, 2, 4 ou 5.
- O Titã Glacial possui 3.000 de vida inicial, velocidade de 0,65 px por frame e recebe mais 500 de vida nas waves 10, 15 e 20.
- O Titã Glacial substitui o Boss vinho na Fase 3; os dois nunca aparecem juntos.

### Inimigos exclusivos da Fase 4

- Macacos Saqueadores possuem 220 de vida e velocidade de 2 px por frame.
- Macacos Saqueadores começam na wave 3 com 1 unidade e recebem mais 1 unidade a cada 4 waves.
- Quantidade de Macacos Saqueadores: waves 3 a 6 = 1; 7 a 10 = 2; 11 a 14 = 3; 15 a 18 = 4; 19 e 20 = 5.
- Enquanto avançam, os Macacos procuram a torre mais próxima dentro de 165 px e arremessam um projétil a cada 1,8 segundo; se uma Isca Blindada estiver nesse alcance, ela recebe prioridade.
- O impacto do Macaco em torres de combate não causa dano: aumenta o intervalo de ataque em 25% durante 2.500 ms e novos impactos renovam a duração. Contra a Isca Blindada, o impacto consome 1 ponto de resistência.
- Onças da Selva possuem 360 de vida e velocidade inicial de 1,7 px por frame.
- Ao ficarem com 50% da vida ou menos, as Onças entram em disparada e passam a se mover 45% mais rápido, atingindo 2,465 px por frame antes de efeitos de lentidão ou congelamento.
- Onças começam na wave 5 com 1 unidade e recebem mais 1 unidade a cada 4 waves.
- Quantidade de Onças: waves 5 a 8 = 1; 9 a 12 = 2; 13 a 16 = 3; 17 a 20 = 4.
- Gorilas da Selva possuem 850 de vida e velocidade de 0,6 px por frame.
- Gorilas começam na wave 7 com 1 unidade e recebem mais 1 unidade a cada 5 waves.
- Quantidade de Gorilas: waves 7 a 11 = 1; 12 a 16 = 2; 17 a 20 = 3.
- A wave 20 da Fase 4 contém 5 Macacos Saqueadores, 4 Onças da Selva e 3 Gorilas adicionais.
- Macacos, Onças e Gorilas são somados aos inimigos comuns, Sabotadores e ao Colosso da Selva.
- Macacos, Onças, Gorilas e o Colosso nunca são criados nas Fases 1, 2, 3 ou 5.
- O Colosso da Selva possui 4.000 de vida inicial, velocidade de 0,55 px por frame e recebe mais 500 de vida nas waves 10, 15 e 20.
- O Colosso da Selva substitui o Boss vinho na Fase 4; os dois nunca aparecem juntos.

### Inimigos exclusivos da Fase 5

- Raposas Ladinas possuem 260 de vida e velocidade de 2,55 px por frame.
- Raposas começam na wave 3 com 1 unidade e recebem mais 1 unidade a cada 4 waves.
- Quantidade de Raposas: waves 3 a 6 = 1; 7 a 10 = 2; 11 a 14 = 3; 15 a 18 = 4; 19 e 20 = 5.
- Javalis Furiosos possuem 950 de vida e velocidade normal de 0,72 px por frame.
- Javalis começam na wave 7 com 1 unidade e recebem mais 1 unidade a cada 5 waves.
- Quantidade de Javalis: waves 7 a 11 = 1; 12 a 16 = 2; 17 a 20 = 3.
- Cada Javali realiza uma arrancada a cada 4.000 ms; a arrancada dura 1.100 ms e multiplica sua velocidade por 1,8, chegando a 1,296 px por frame antes de efeitos glaciais.
- Corujas Sombrias possuem 420 de vida e velocidade de 1,4 px por frame.
- Corujas começam na wave 9 com 1 unidade e recebem mais 1 unidade a cada 5 waves.
- Quantidade de Corujas: waves 9 a 13 = 1; 14 a 18 = 2; 19 e 20 = 3.
- Enquanto avançam, as Corujas procuram a torre mais próxima dentro de 190 px e disparam a cada 2,1 segundos; se uma Isca Blindada estiver nesse alcance, ela recebe prioridade.
- O impacto da Coruja em torres de combate reduz o alcance em 25% durante 3.000 ms e novos impactos renovam a duração. Contra a Isca Blindada, o impacto consome 1 ponto de resistência.
- A wave 20 da Fase 5 contém 5 Raposas Ladinas, 3 Javalis Furiosos e 3 Corujas Sombrias adicionais.
- Raposas, Javalis e Corujas são somados aos inimigos comuns, Sabotadores e ao Urso Ancestral.
- Raposas, Javalis, Corujas e o Urso nunca são criados nas Fases 1, 2, 3 ou 4.
- O Urso Ancestral possui 3.500 de vida inicial, velocidade de 0,45 px por frame e recebe mais 500 de vida nas waves 10, 15 e 20.
- O primeiro Rugido Ancestral fica disponível 3.500 ms depois do surgimento do Urso. Depois de usado, a habilidade entra em recarga por 6.000 ms.
- Quando a habilidade está disponível e existe ao menos uma torre de combate a até 230 px, o Urso ruge e atordoa simultaneamente todas as torres de combate dentro do raio por 1.400 ms.
- Uma torre atordoada não procura alvo, não dispara e não gera dinheiro. Ao fim do efeito, ela volta a operar normalmente sem perder nível, resistência ou modo de alvo.
- Isca Blindada e Amplificador Pixel não são afetados pelo rugido porque não são torres de combate.
- Se nenhuma torre de combate estiver no alcance, o Urso guarda o rugido disponível até encontrar um alvo válido.
- Pausar a partida congela a recarga do rugido, sua animação e o tempo restante de atordoamento.
- O Urso Ancestral substitui o Boss vinho na Fase 5; os dois nunca aparecem juntos.

### Inimigos exclusivos da Fase 7

- Mosquitos do Brejo possuem 340 de vida e velocidade de 3 px por frame.
- Mosquitos começam na wave 3 com 1 unidade e recebem mais 1 unidade a cada 4 waves; a wave 20 contém 5.
- Sapos Venenosos possuem 650 de vida e velocidade de 1,35 px por frame.
- Sapos começam na wave 5 com 1 unidade e recebem mais 1 unidade a cada 4 waves; a wave 20 contém 4.
- Guardiões de Lodo possuem 1.400 de vida e velocidade de 0,62 px por frame.
- Guardiões começam na wave 7 com 1 unidade e recebem mais 1 unidade a cada 5 waves; a wave 20 contém 3.
- Mosquitos, Sapos e Guardiões são somados aos inimigos comuns, Sabotadores e à Hidra do Pântano.
- Inimigos exclusivos das Fases 2 a 6 não aparecem na Fase 7.
- A Hidra do Pântano possui 3.800 de vida inicial, velocidade de 0,7 px por frame e recebe mais 500 de vida nas waves 10, 15 e 20.
- Ao alcançar 50% da vida pela primeira vez, a Hidra ativa permanentemente sua regeneração, restaura 40 de vida por segundo e nunca ultrapassa a própria vida máxima.
- Pausar a partida congela a regeneração da Hidra; derrotá-la encerra o efeito imediatamente.
- A Hidra do Pântano substitui todos os outros Bosses na Fase 7.

### Sabotador

- O Sabotador aparece nas sete fases, possui 75 de vida e velocidade de 1,1 px por frame.
- Enquanto avança pelo caminho, procura a torre mais próxima dentro de 180 px e dispara a cada 1,2 segundo; se uma Isca Blindada estiver nesse alcance, ela recebe prioridade mesmo que outra torre esteja mais perto.
- Os projéteis perseguem a torre escolhida; se ela for vendida ou destruída antes do impacto, o projétil desaparece.
- Cada impacto permanece registrado mesmo depois de melhorar a torre. Ao receber o sexto tiro, a torre é destruída sem devolver créditos.
- Torres danificadas exibem seis blocos de resistência, apagados conforme recebem tiros.
- A Isca Blindada exibe dez blocos e é destruída somente no décimo impacto.

## Vitória

- Na campanha normal, a wave 20 é a última da partida; a wave 21 não é iniciada.
- A partida é vencida depois que todos os inimigos da wave 20 forem derrotados.
- O painel **VITÓRIA** aparece e permanece até a escolha entre repetir a fase, voltar ao menu ou iniciar a próxima fase.
- A conclusão e o desbloqueio da próxima fase são salvos antes de o painel aparecer.
- Ao concluir a wave 20, a vitória concede 20 Fragmentos de Pixel pela quantidade de waves alcançadas.
- O modo Waves infinitas nunca aciona esta condição de vitória e, quando a base é invadida, concede metade da wave alcançada arredondada para baixo.

## Progressão das fases

- A campanha possui atualmente 7 fases com as mesmas regras centrais e duração de 20 waves; as Fases 2 a 7 aumentam a dificuldade com inimigos exclusivos próprios.
- A Fase 1 mantém o mapa de campo verde.
- A Fase 2 usa um trajeto próprio pelo mapa de deserto, com comprimento aproximado ao caminho da Fase 1.
- A Fase 3 usa um trajeto próprio em zigue-zague pelo mapa ártico, também com comprimento aproximado aos caminhos anteriores.
- A Fase 4 usa um trajeto próprio longo e anguloso pelas ruínas da selva, com comprimento de 3.030 px.
- A Fase 5 possui duas entradas com trajetos de 2.960 px cada. Os ramos norte e sul têm o mesmo comprimento, convergem no centro do mapa e compartilham a única torre-base.
- A Fase 6 possui um trajeto vulcânico de 3.050 px e limite de 18 torres.
- A Fase 7 possui um trajeto pantanoso de 3.170 px e limite de 20 torres.
- A Fase 1 começa desbloqueada e é sempre a fase selecionada ao carregar a página.
- A Fase 2 começa bloqueada e só é desbloqueada depois da vitória na Fase 1.
- A Fase 3 começa bloqueada e só é desbloqueada depois da vitória na Fase 2.
- A Fase 4 começa bloqueada e só é desbloqueada depois da vitória na Fase 3.
- A Fase 5 começa bloqueada e só é desbloqueada depois da vitória na Fase 4.
- A Fase 6 começa bloqueada e só é desbloqueada depois da vitória na Fase 5.
- A Fase 7 começa bloqueada e só é desbloqueada depois da vitória na Fase 6.
- Concluir uma fase significa derrotar todos os inimigos de sua wave 20.
- Derrotas e partidas abandonadas não desbloqueiam fases.
- Fases concluídas continuam disponíveis para serem jogadas novamente.
- O maior número de fase concluída é salvo no armazenamento local do navegador e preservado após recarregar a página.
- O progresso usa a versão atual da chave de armazenamento; dados anteriores que liberavam a Fase 2 indevidamente são ignorados.
- O seletor impede a escolha de uma fase bloqueada.
- A estrutura de desbloqueio é sequencial: cada nova fase adicionada deverá exigir a conclusão da anterior.

## Trajetórias das fases

- O caminho usado para desenhar o mapa, mover inimigos e impedir torres é determinado pela fase selecionada.
- Fase 1: (0,525) → (160,525) → (160,150) → (350,150) → (350,600) → (570,600) → (570,100) → (800,100) → (800,500) → (1030,500) → (1030,220) → (1200,220).
- Fase 2: (0,120) → (220,120) → (220,620) → (460,620) → (460,180) → (700,180) → (700,520) → (930,520) → (930,80) → (1150,80) → (1150,380) → (1200,380).
- Fase 3: (0,360) → (210,360) → (210,80) → (470,80) → (470,620) → (720,620) → (720,180) → (970,180) → (970,560) → (1160,560) → (1160,320) → (1200,320).
- Fase 4: (0,650) → (150,650) → (150,370) → (360,370) → (360,90) → (600,90) → (600,610) → (840,610) → (840,180) → (1080,180) → (1080,500) → (1200,500).
- Fase 5, ramo norte: (0,130) → (180,130) → (180,300) → (400,300) → (400,170) → (650,170) → (650,350) → trecho compartilhado.
- Fase 5, ramo sul: (0,570) → (180,570) → (180,400) → (400,400) → (400,530) → (650,530) → (650,350) → trecho compartilhado.
- Fase 5, trecho compartilhado: (650,350) → (820,350) → (820,100) → (1040,100) → (1040,600) → (900,600) → (900,470) → (1150,470) → (1150,350) → (1200,350).
- Fase 6: (0,350) → (140,350) → (140,90) → (360,90) → (360,540) → (580,540) → (580,170) → (800,170) → (800,620) → (1010,620) → (1010,300) → (1200,300).
- Fase 7: (0,100) → (180,100) → (180,560) → (390,560) → (390,220) → (610,220) → (610,620) → (830,620) → (830,140) → (1050,140) → (1050,430) → (1200,430).
- Cada entrada é desenhada no início de seu trajeto, e a torre-base protegida fica encaixada na borda do ponto final compartilhado.
- Na Fase 5, inimigos sucessivos alternam entre a entrada norte e a entrada sul; a alternância é reiniciada ao começar ou reiniciar a partida.
- Quantidade de waves, economia e regras de vitória permanecem iguais nas sete fases; a Fase 7 adiciona Mosquitos do Brejo, Sapos Venenosos, Guardiões de Lodo e a Hidra do Pântano.

### Mudança: Fase 3 Ártica

**Objetivo:** adicionar uma terceira fase visualmente distinta, desbloqueada pela progressão normal da campanha.
**Alterar:** incluir a Fase 3 com tema ártico, limite de 12 torres e trajetória exclusiva de 3.080 px.
**Não alterar:** dinheiro inicial, waves, inimigos comuns, recompensa por tiro e condições de vitória ou derrota.
**Aceitação:**
- Dado que a Fase 2 ainda não foi concluída, a Fase 3 aparece bloqueada e não pode ser selecionada.
- Dado que a Fase 2 foi concluída, a Fase 3 fica disponível e seu tema substitui imediatamente o fundo do lobby.
- Ao iniciar a Fase 3, inimigos percorrem a trajetória ártica e o mapa exibe neve, caminho de gelo, iglus, pinguins, pinheiros nevados, blocos de gelo e lago congelado.
- Escorpiões, Múmias e o Faraó de Areia permanecem exclusivos da Fase 2.

### Mudança: inimigos exclusivos da Fase 3

**Objetivo:** aumentar a identidade e a dificuldade do mapa ártico com unidades próprias.
**Alterar:** adicionar Lobos de Gelo desde a wave 3 e Yetis desde a wave 7, usando a progressão de quantidades definida na seção de waves.
**Não alterar:** inimigos comuns, Sabotadores, economia, trajetória, limite de torres ou condição de vitória da Fase 3.
**Aceitação:**
- Dada a Fase 3, quando a wave 3 começar, então 1 Lobo de Gelo é acrescentado à composição comum.
- Dada a Fase 3, quando a wave 7 começar, então 2 Lobos de Gelo e 1 Yeti são acrescentados.
- Dada a Fase 3, quando a wave 20 começar, então 5 Lobos de Gelo e 3 Yetis são acrescentados junto ao Titã Glacial.
- Dadas as Fases 1, 2, 4 ou 5, Lobos de Gelo e Yetis nunca são criados.

### Mudança: Fase 4 Ruínas da Selva

**Objetivo:** adicionar uma quarta fase visualmente distinta, desbloqueada pela progressão normal da campanha.
**Alterar:** incluir a Fase 4 com tema de selva, limite de 14 torres, trajetória exclusiva de 3.030 px, inimigos próprios e Colosso da Selva.
**Não alterar:** dinheiro inicial, duração de 20 waves, inimigos comuns, Sabotadores, recompensa por tiro e condições de vitória ou derrota.
**Aceitação:**
- Dado que a Fase 3 ainda não foi concluída, a Fase 4 aparece bloqueada e não pode ser selecionada.
- Dado que a Fase 3 foi concluída, a Fase 4 fica disponível, a Torre Besta é liberada e o tema de selva substitui imediatamente o fundo do lobby.
- Ao iniciar a Fase 4, inimigos percorrem a trajetória própria e o mapa exibe vegetação, caminho de terra, árvores, cipós, flores, lagos e ruínas pixeladas.
- Na wave 3, 1 Macaco Saqueador é acrescentado à composição comum.
- Na wave 5, 1 Onça da Selva é acrescentada e ativa a disparada ao ficar com 50% da vida ou menos.
- Na wave 7, 2 Macacos Saqueadores, 1 Onça da Selva e 1 Gorila da Selva são acrescentados.
- Na wave 20, 5 Macacos, 4 Onças e 3 Gorilas são acrescentados junto ao Colosso da Selva.
- Inimigos exclusivos das Fases 2 e 3 não aparecem na Fase 4.

### Mudança: Fase 5 Bosque do Crepúsculo

**Objetivo:** adicionar uma quinta fase de floresta temperada que exige defender duas entradas convergentes.
**Alterar:** incluir a Fase 5 com tema de outono, limite de 16 torres, dois trajetos equivalentes de 2.960 px, inimigos próprios e Urso Ancestral.
**Não alterar:** dinheiro inicial, duração de 20 waves, inimigos comuns, Sabotadores, recompensa por tiro, fases anteriores e condições de vitória ou derrota.
**Aceitação:**
- Dado que a Fase 4 ainda não foi concluída, a Fase 5 aparece bloqueada e não pode ser selecionada.
- Dado que a Fase 4 foi concluída, a Fase 5 e a Torre de Esporos ficam disponíveis, e o tema da nova fase substitui imediatamente o fundo do lobby.
- Ao iniciar a Fase 5, o mapa exibe duas entradas, alterna inimigos entre elas e conduz os dois caminhos até a mesma torre-base.
- Os dois caminhos possuem exatamente 2.960 px, impedem construção e aceitam Minas Terrestres em toda a própria extensão.
- Na wave 3, 1 Raposa Ladina é acrescentada à composição comum.
- Na wave 7, 2 Raposas e 1 Javali Furioso são acrescentados.
- Na wave 9, 2 Raposas, 1 Javali e 1 Coruja Sombria são acrescentados.
- Na wave 20, 5 Raposas, 3 Javalis e 3 Corujas são acrescentados junto ao Urso Ancestral.
- Inimigos exclusivos das Fases 2, 3 e 4 não aparecem na Fase 5.

### Mudança: Fase 6 Forja Vulcânica

**Objetivo:** adicionar uma sexta fase com identidade vulcânica, novos inimigos, uma torre de rajada tripla e um Boss cuja dificuldade vem de uma transformação, não de aumentos sucessivos de vida.
**Alterar:** incluir a Fase 6 com limite de 18 torres, trajeto exclusivo de 3.050 px, Obliterador, inimigos vulcânicos e Titã de Obsidiana.
**Não alterar:** dinheiro inicial, duração de 20 waves, inimigos comuns, Sabotadores, recompensa por tiro, fases anteriores e condições de vitória ou derrota.
**Aceitação:**
- Antes de concluir a Fase 5, a Fase 6 e o Obliterador permanecem bloqueados.
- Depois de concluir a Fase 5, a Fase 6 e o Obliterador são liberados permanentemente, inclusive ao repetir fases anteriores.
- Ao selecionar a Fase 6, o lobby e o mapa adotam o tema vulcânico com basalto, lava, vulcões e cristais de obsidiana.
- Ao iniciar a Fase 6, a trilha procedural da Forja começa e todas as outras trilhas da campanha são encerradas.
- Na wave 3, 1 Morcego de Fogo é acrescentado; uma nova unidade surge a cada 4 waves, totalizando 5 na wave 20.
- Na wave 5, 1 Lagarto Vulcânico é acrescentado; uma nova unidade surge a cada 4 waves, totalizando 4 na wave 20.
- Na wave 7, 1 Golem de Magma é acrescentado; uma nova unidade surge a cada 5 waves, totalizando 3 na wave 20.
- Inimigos exclusivos das Fases 2 a 5 não aparecem na Fase 6.
- O Titã de Obsidiana substitui os demais Bosses nas waves 5, 10, 15 e 20 e mantém 3.200 de vida em todas as quatro aparições.
- Antes da transformação, a carapaça reduz todo dano recebido em 15% e funciona como um limite de fase: um ataque não pode reduzir a vida para menos de 50%.
- Ao alcançar 50% da vida pela primeira vez, a carapaça rompe, o Titã acelera em 65% e libera respectivamente 2, 3, 4 ou 5 Fragmentos de Magma conforme a aparição.
- A transformação ocorre uma única vez por Titã; os Fragmentos começam no ponto atual do Boss, seguem o mesmo caminho e precisam ser derrotados para concluir a wave.
- O aviso de Boss da fase destaca **OBSIDIANO**.

### Mudança: Fase 7 Pântano Tóxico

**Objetivo:** iniciar o segundo capítulo da campanha com um novo bioma, elenco exclusivo e um Boss que exige dano contínuo.
**Alterar:** incluir a Fase 7 com limite de 20 torres, trajeto exclusivo de 3.170 px, cenário pantanoso, música procedural própria, três inimigos exclusivos e a Hidra do Pântano.
**Não alterar:** dinheiro inicial, duração de 20 waves, inimigos comuns, Sabotadores, recompensa por tiro, fases anteriores, acesso pelo portal ou condição de vitória e derrota.
**Aceitação:**
- Antes de concluir a Fase 6, a Fase 7 permanece bloqueada e não pode ser selecionada nem iniciada.
- Depois de concluir a Fase 6, a Fase 7 é liberada permanentemente e o botão **Próxima fase** pode iniciá-la diretamente.
- Ao selecionar a Fase 7, lobby e mapa adotam o Pântano Tóxico, com lodo verde-escuro, poças venenosas, árvores retorcidas, juncos, bolhas e cogumelos luminosos.
- Ao iniciar a Fase 7, a trilha procedural do pântano começa e todas as outras trilhas da campanha são encerradas.
- Na wave 3, 1 Mosquito do Brejo é acrescentado; uma nova unidade surge a cada 4 waves, totalizando 5 na wave 20.
- Na wave 5, 1 Sapo Venenoso é acrescentado; uma nova unidade surge a cada 4 waves, totalizando 4 na wave 20.
- Na wave 7, 1 Guardião de Lodo é acrescentado; uma nova unidade surge a cada 5 waves, totalizando 3 na wave 20.
- Inimigos exclusivos das Fases 2 a 6 não aparecem na Fase 7.
- A Hidra do Pântano substitui os demais Bosses nas waves 5, 10, 15 e 20, com respectivamente 3.800, 4.300, 4.800 e 5.300 de vida.
- Ao alcançar 50% da vida, a Hidra ativa permanentemente a regeneração de 40 de vida por segundo; o efeito pausa com a partida e não ultrapassa a vida máxima.
- O aviso de Boss da fase destaca **HIDRA**.
- A Dimensão Glitch passa a usar somente o número interno 8, permanece ausente da lista de fases e continua acessível exclusivamente pelo portal da Fase 1.

### Mudança: Obliterador

**Objetivo:** recompensar a conclusão da Fase 5 com uma torre de alto dano em rajadas espaçadas.
**Alterar:** adicionar o Obliterador com três canos e três projéteis laser por ataque.
**Não alterar:** recompensa de 20 créditos por ataque, espaçamento mínimo, regras de alvo, melhoria e venda das demais torres.
**Aceitação:**
- Cada ataque cria exatamente 3 lasers contra o mesmo alvo e concede a recompensa por tiro apenas uma vez.
- O dano mostrado é o dano de cada laser, não a soma da rajada.
- O seletor, o mapa e o Álbum reutilizam o mesmo desenho pixelado com detalhes vermelhos e três canos em todos os níveis.

| Nível | Custo | Dano por laser | Alcance | Ataque | Visual |
| --- | --- | --- | --- | --- | --- |
| 0 | 550 | 48 | 230 px | 1.600 ms | Obsidiana e vermelho |
| 1 | 650 | 65 | 245 px | 1.500 ms | Vermelho reforçado |
| 2 | 850 | 88 | 260 px | 1.400 ms | Rubro e dourado |
| 3 | 1.100 | 120 | 280 px | 1.250 ms | Rubro intenso e amarelo |

### Mudança: Rugido Ancestral do Urso

**Objetivo:** diferenciar o chefe do Bosque do Crepúsculo com uma habilidade própria e reduzir sua vida para manter a fase equilibrada.
**Alterar:** reduzir a vida inicial do Urso Ancestral de 5.000 para 3.500 e adicionar um rugido periódico que atordoa torres de combate próximas.
**Não alterar:** velocidade de 0,45 px por frame, aumento de 500 de vida por aparição, composição das waves, inimigos anteriores ou comportamento de Isca Blindada e Amplificador Pixel.
**Aceitação:**
- Na wave 5, o Urso possui 3.500 de vida; nas waves 10, 15 e 20 possui respectivamente 4.000, 4.500 e 5.000.
- Durante os primeiros 3.500 ms após surgir, o Urso não pode rugir.
- Com uma torre de combate a até 230 px, o rugido atordoa essa torre durante 1.400 ms, exibe o efeito pixelado no Urso e na torre e reproduz o som gravado.
- Torres de combate fora do raio, Isca Blindada e Amplificador Pixel continuam funcionando normalmente.
- Um novo rugido só pode acontecer 6.000 ms depois do uso anterior.
- Desativar ou zerar o volume dos efeitos impede o áudio do rugido sem desativar a habilidade.
- Abrir o menu da partida congela tanto a recarga quanto o atordoamento e os retoma com o mesmo tempo restante.

## Derrota e reinício

- Se qualquer inimigo tocar a torre-base no final do caminho, a partida termina imediatamente.
- O contato usa um núcleo de 18 px ao redor da torre-base somado ao tamanho do inimigo, fazendo a derrota acontecer quando o sprite encosta na estrutura.
- O painel grande **GAME OVER** aparece no centro da tela e permanece aberto até a escolha do jogador.
- A tela de derrota informa **SUA BASE FOI INVADIDA**.
- O texto complementar usa apenas **base**, sem chamar a estrutura de torre-base.
- O painel permanece aberto até o jogador escolher **Recomeçar fase** ou **Voltar ao menu**.

### Mudança: torre-base no fim do caminho

**Objetivo:** representar claramente o ponto que o jogador precisa defender.
**Alterar:** substituir o portão de saída por uma torre-base pixelada temática e encerrar a partida no primeiro contato de qualquer inimigo com ela.
**Não alterar:** trajetórias, velocidades, waves, economia e progressão.
**Aceitação:**
- Dada qualquer uma das sete fases, a torre-base aparece no fim da trajetória com as cores do tema atual.
- Dado um inimigo vivo, quando seu sprite tocar a torre-base, então a derrota é acionada imediatamente.
- Dado um inimigo derrotado antes do contato, ele é removido normalmente e não causa Game Over.
- Após a derrota, o painel **GAME OVER** permanece aberto e oferece recomeçar a fase ou voltar ao menu.

## Melhorias de torre

- Clique em uma torre para selecioná-la e use o botão **Melhorar torre**.
- A Torre padrão, o Canhão pesado, a Torre Glacial, a Torre Besta, a Torre de Esporos e o Obliterador podem receber no máximo 3 melhorias; a Isca Blindada e o Amplificador Pixel não possuem melhorias.
- O Canhão pesado possui dano base 20, superior ao dano 15 da Torre padrão nível 1.
- Mesmo no nível 3, o alcance 140 do Canhão pesado permanece abaixo do alcance 150 da Torre padrão nível 0.

### Torre padrão

| Nível | Custo | Dano | Alcance | Ataque | Visual |
| --- | --- | --- | --- | --- | --- |
| 0 | — | 10 | 150 px | 500 ms | Azul |
| 1 | 200 | 15 | 165 px | 450 ms | Azul-claro |
| 2 | 300 | 22 | 180 px | 400 ms | Dourado |
| 3 | 450 | 30 | 200 px | 350 ms | Roxo |

### Canhão pesado

| Nível | Custo | Dano | Alcance | Ataque | Visual |
| --- | --- | --- | --- | --- | --- |
| 0 | 250 | 20 | 110 px | 700 ms | Vermelho-terra |
| 1 | 300 | 28 | 118 px | 650 ms | Laranja |
| 2 | 420 | 38 | 128 px | 600 ms | Dourado-escuro |
| 3 | 560 | 50 | 140 px | 550 ms | Vermelho-escuro |

#### Mudança: bola de canhão própria

**Objetivo:** diferenciar claramente o disparo do Canhão pesado do projétil luminoso da Torre padrão.
**Alterar:** desenhar uma bola de canhão pixelada de 18 px inspirada na imagem autoral `references/Captura de tela 2026-08-26 140653.png`, com corpo de carvão, bordas em degraus, sombra inferior e brilho em cruz.
**Não alterar:** dano, velocidade, trajetória, perseguição do alvo, recompensa por tiro ou cadência do Canhão pesado.
**Aceitação:**
- Somente o Canhão pesado dispara a bola de canhão escura; a Torre padrão mantém seu projétil luminoso.
- A bola não possui fogo, rastro luminoso nem cauda atrás dela.
- O desenho permanece pixelado e centralizado durante todo o movimento.

### Torre Glacial

| Nível | Custo | Dano | Alcance | Ataque | Lentidão | Congela | Visual |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 350 | 18 | 170 px | 800 ms | 25% por 1.400 ms | 4 acertos por 500 ms | Cristal azul-gelo |
| 1 | 420 | 25 | 180 px | 740 ms | 30% por 1.600 ms | 4 acertos por 600 ms | Cristal ciano |
| 2 | 560 | 34 | 195 px | 680 ms | 35% por 1.800 ms | 3 acertos por 700 ms | Cristal branco |
| 3 | 720 | 46 | 210 px | 600 ms | 40% por 2.200 ms | 3 acertos por 800 ms | Cristal azul e dourado |

- A lentidão é renovada por novos acertos e afeta inimigos comuns e Bosses.
- O congelamento interrompe somente inimigos comuns; Bosses continuam em movimento sob o efeito da lentidão.

### Torre Besta

| Nível | Custo | Dano | Alcance | Ataque | Visual |
| --- | --- | --- | --- | --- | --- |
| 0 | 400 | 55 | 210 px | 1.100 ms | Madeira e bronze |
| 1 | 480 | 75 | 225 px | 1.000 ms | Madeira clara |
| 2 | 650 | 100 | 240 px | 900 ms | Madeira reforçada |
| 3 | 850 | 135 | 260 px | 800 ms | Madeira escura e dourada |

- A Torre Besta dispara virotes próprios a 10 px por frame.
- Sua função é causar alto dano por disparo e cobrir longo alcance, compensados pelo custo e pelo intervalo de ataque maiores.

### Torre de Esporos

| Nível | Custo | Dano em área | Raio da área | Alcance | Ataque | Visual |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | 475 | 42 | 60 px | 185 px | 1.050 ms | Cogumelo rosa e madeira |
| 1 | 550 | 58 | 65 px | 195 px | 950 ms | Cogumelo rosa-claro |
| 2 | 725 | 78 | 72 px | 207 px | 850 ms | Cogumelo violeta e dourado |
| 3 | 950 | 105 | 80 px | 220 px | 750 ms | Cogumelo ancestral roxo |

- A Torre de Esporos dispara orbes próprios a 7,5 px por frame.
- Cada impacto aplica o dano integral a todo inimigo vivo cujo centro esteja dentro do raio da nuvem, incluindo o alvo original uma única vez.
- Cada disparo concede somente a recompensa normal de 20 créditos, independentemente da quantidade de inimigos atingidos.

## Construção de torres

- A Torre padrão é o tipo selecionado no início de cada partida.
- A Torre padrão fica disponível em todas as fases.
- O Canhão pesado começa bloqueado e é desbloqueado permanentemente ao concluir a Fase 1.
- Depois do desbloqueio, o Canhão pesado fica disponível em todas as fases, inclusive ao repetir a Fase 1.
- Enquanto estiver bloqueado, o botão do Canhão pesado fica desabilitado, exibe **Conclua Fase 1** e nenhuma tentativa de construção desconta créditos.
- A Torre Glacial começa bloqueada e é desbloqueada permanentemente ao concluir a Fase 2.
- Depois do desbloqueio, a Torre Glacial fica disponível em todas as fases atuais e futuras, inclusive ao repetir fases anteriores.
- Enquanto estiver bloqueada, seu botão fica desabilitado, exibe **Conclua Fase 2** e nenhuma tentativa de construção desconta créditos.
- A Torre Besta começa bloqueada e é desbloqueada permanentemente ao concluir a Fase 3.
- Depois do desbloqueio, a Torre Besta fica disponível em todas as fases atuais e futuras, inclusive ao repetir fases anteriores.
- Enquanto estiver bloqueada, seu botão fica desabilitado, exibe **Conclua Fase 3** e nenhuma tentativa de construção desconta créditos.
- A Torre de Esporos começa bloqueada e é desbloqueada permanentemente ao concluir a Fase 4.
- Depois do desbloqueio, a Torre de Esporos fica disponível em todas as fases, inclusive ao repetir as Fases 1 a 4.
- Enquanto estiver bloqueada, seu botão fica desabilitado, exibe **Conclua Fase 4** e nenhuma tentativa de construção desconta créditos.
- O Obliterador começa bloqueado e é desbloqueado permanentemente ao concluir a Fase 5.
- Depois do desbloqueio, o Obliterador fica disponível em todas as fases, inclusive ao repetir as Fases 1 a 5.
- Enquanto estiver bloqueado, seu botão fica desabilitado, exibe **Conclua Fase 5** e nenhuma tentativa de construção desconta créditos.
- A Isca Blindada começa bloqueada e seu botão exibe **Compre na Loja**.
- Depois de comprada, a Isca Blindada fica permanentemente disponível em todas as fases e custa 200 créditos em cada construção.
- O Amplificador Pixel também começa bloqueado, custa 45 Fragmentos na Loja e, depois da compra permanente, custa 300 créditos para ser construído.
- A Mina Terrestre começa bloqueada, custa 25 Fragmentos na Loja e, depois da compra permanente, custa 100 créditos para ser armada em qualquer fase.
- A Bomba Pesada começa bloqueada, custa 40 Fragmentos na Loja e, depois da compra permanente, custa 200 créditos para ser posicionada em qualquer fase.
- A Torre de Raios começa bloqueada, custa 60 Fragmentos na Loja e, depois da compra permanente, custa 425 créditos para ser construída em qualquer fase.
- O Lança-Chamas começa bloqueado, custa 100 Fragmentos na Loja e, depois da compra permanente, custa 650 créditos para ser construído em qualquer fase.
- A Mina Congelante começa bloqueada, custa 35 Fragmentos na Loja e, depois da compra permanente, custa 125 créditos para ser armada em qualquer fase.
- O jogador escolhe o tipo de torre no painel vertical à direita do mapa e depois clica em uma área válida.
- O custo, dano, alcance, velocidade e aparência são definidos pelo tipo selecionado.
- Os dez tipos de torre compartilham o limite da fase atual: 10 torres na Fase 1, 12 nas Fases 2 e 3, 14 na Fase 4, 16 na Fase 5, 18 na Fase 6 e 20 na Fase 7.
- Além do limite geral, podem existir no máximo 2 Iscas Blindadas por partida.
- Além do limite geral, pode existir no máximo 1 Amplificador Pixel por partida.
- Além do limite geral, podem existir no máximo 2 Lança-Chamas por partida.
- A Mina Terrestre não conta como torre, não ocupa o limite da fase e possui um limite próprio de 5 unidades armadas.
- A Mina Congelante não conta como torre, não ocupa o limite da fase e possui um limite próprio de 4 unidades armadas.
- A Bomba Pesada não conta como torre, não ocupa o limite da fase e possui um limite próprio de 3 unidades posicionadas.
- O rodapé do lobby e o HUD da partida exibem o limite correspondente à fase selecionada.
- O espaçamento mínimo de 70 px e a recompensa de 20 por ataque permanecem iguais nas sete fases; a rajada tripla do Obliterador concede a recompensa uma única vez.
- Selecionar um tipo sem dinheiro suficiente não desconta créditos nem constrói a torre.

### Mudança: desbloqueio permanente do Canhão pesado

**Objetivo:** permitir que a recompensa por concluir a Fase 1 também seja usada ao repetir fases anteriores.
**Alterar:** substituir o desbloqueio condicionado ao número da fase por um desbloqueio global condicionado à conclusão da Fase 1.
**Não alterar:** custo de 250 créditos, dano, alcance, velocidade de ataque, melhorias ou limites de torres.
**Aceitação:**
- Antes de concluir a Fase 1, o botão permanece desabilitado e mostra **Conclua Fase 1**.
- Ao concluir a Fase 1, o Canhão pesado é liberado imediatamente e o progresso é salvo.
- Depois do desbloqueio, recarregar a página ou repetir a Fase 1 mantém o Canhão pesado disponível.
- Abandonar ou perder a Fase 1 não desbloqueia o Canhão pesado.

### Mudança: Torre Glacial e Titã Glacial

**Objetivo:** dar à Fase 3 uma torre de controle de inimigos e um Boss exclusivo.
**Alterar:** adicionar a Torre Glacial desbloqueada pela conclusão da Fase 2 e substituir o Boss vinho da Fase 3 pelo Titã Glacial. A Besta estreia na Fase 4.
**Não alterar:** limite de torres, recompensa por tiro, trajetória, quantidade de waves, inimigos comuns ou progressão sequencial.
**Aceitação:**
- Antes de concluir a Fase 2, a Torre Glacial aparece bloqueada e não pode ser construída.
- Depois de concluir a Fase 2, a Torre Glacial permanece disponível nas fases atuais e futuras.
- A Torre Glacial nível 0 custa 350, causa 18 de dano, alcança 170 px, ataca a cada 800 ms e dispara estilhaços a 8 px por frame.
- Seus acertos causam 25% de lentidão por 1.400 ms e congelam inimigos comuns por 500 ms a cada 4 acertos.
- Bosses recebem a lentidão, mas nunca ficam completamente congelados.
- A Torre Glacial possui três melhorias e usa visual de cristal e projétil próprios no mapa e no Álbum.
- Nas waves 5, 10, 15 e 20 da Fase 3, surge somente o Titã Glacial como Boss.
- O Titã Glacial começa com 3.000 de vida, recebe mais 500 por aparição e se move a 0,65 px por frame.

### Mudança: Torre Besta

**Objetivo:** recompensar a conclusão da Fase 3 com uma arma de alto dano para a Fase 4.
**Alterar:** adicionar a Torre Besta com visual e projétil próprios, desbloqueio global pela conclusão da Fase 3 e três melhorias.
**Não alterar:** progressão sequencial, recompensa por tiro, espaçamento mínimo ou regras de construção, melhoria e venda.
**Aceitação:**
- Antes de concluir a Fase 3, a Torre Besta aparece bloqueada e não pode ser construída.
- Depois de concluir a Fase 3, a Torre Besta permanece disponível em todas as fases atuais e futuras.
- No nível 0, custa 400, causa 55 de dano, alcança 210 px, ataca a cada 1.100 ms e dispara virotes a 10 px por frame.
- As melhorias usam exatamente os valores da tabela e mantêm no máximo o nível 3.
- O mapa e o Álbum usam o mesmo desenho pixelado da Besta em cada nível.

### Mudança: Torre de Esporos

**Objetivo:** recompensar a conclusão da Fase 4 com uma defesa de área que estreia no Bosque do Crepúsculo e permanece útil ao repetir a campanha.
**Alterar:** adicionar a Torre de Esporos com desbloqueio permanente pela conclusão da Fase 4, projétil e nuvem de dano em área próprios e três melhorias.
**Não alterar:** desbloqueio sequencial das fases, inimigos, trajetórias, limite de 16 torres da Fase 5, recompensa de 20 créditos por disparo, espaçamento, melhoria ou venda.
**Aceitação:**
- Antes de concluir a Fase 4, a Torre de Esporos aparece desabilitada com o texto **Conclua Fase 4** e não pode ser construída.
- Ao concluir a Fase 4, a Torre de Esporos é liberada imediatamente junto da Fase 5 e o progresso é salvo.
- Depois do desbloqueio, recarregar a página ou repetir qualquer Fase de 1 a 5 mantém a Torre de Esporos disponível.
- Abandonar ou perder a Fase 4 não desbloqueia a Torre de Esporos.
- No nível 0, custa 475, causa 42 de dano em uma área de 60 px, alcança 185 px, ataca a cada 1.050 ms e dispara orbes a 7,5 px por frame.
- No impacto, todos os inimigos vivos dentro da área recebem o dano uma vez; inimigos fora dela não recebem dano.
- Acertar vários inimigos com o mesmo orbe concede somente os 20 créditos do disparo.
- As três melhorias usam exatamente os valores da tabela, mantêm o nível máximo 3 e atualizam dano, área, alcance, cadência e visual.
- O seletor, o mapa e o Álbum usam o mesmo desenho pixelado de cogumelo em cada nível.

### Mudança: Loja, Fragmentos de Pixel e Isca Blindada

**Objetivo:** permitir comprar uma defesa especial que atraia os ataques de Sabotadores, Macacos e Corujas.
**Alterar:** adicionar uma Loja persistente no lobby, uma moeda de Fragmentos de Pixel e a Isca Blindada como primeiro item, incluindo novos inimigos atiradores futuros em sua prioridade.
**Não alterar:** desbloqueio sequencial das fases e torres existentes, limites gerais por fase, trajetórias, economia de tiros ou atributos dos inimigos.
**Aceitação:**
- Um jogador sem dados salvos começa com 0 Fragmentos de Pixel.
- A Loja mostra a Isca Blindada, o Amplificador Pixel, a Mina Terrestre e a Bomba Pesada com seus desenhos pixelados, preços e o saldo atual.
- A Loja é dividida nas abas **Torres**, **Minas** e **Melhorias**; Isca Blindada e Amplificador Pixel aparecem somente em **Torres**.
- A aba **Minas** contém a Mina Terrestre e a Bomba Pesada. A aba **Melhorias** ainda não possui itens e exibe um painel **Em breve**, sem botão de compra.
- Trocar de aba não altera o saldo, as compras salvas nem a categoria dos itens.
- Comprar a Isca desconta 30 Fragmentos uma única vez, salva a compra localmente e libera seu botão em todas as fases, inclusive após recarregar a página.
- Com saldo entre 0 e 29, o botão de compra permanece desabilitado e a validação da função também impede liberar a Isca ou produzir saldo negativo.
- Os registros da Loja usam a versão 2 da chave local; registros da primeira versão, criada antes da validação reforçada, são ignorados sem alterar o saldo de Fragmentos.
- O saldo de Fragmentos usa a versão 2 da chave local e começa em 0; o saldo da versão anterior é ignorado.
- Sem a compra, o botão permanece desabilitado com o texto **Compre na Loja** e nenhuma tentativa desconta créditos.
- Na partida, a Isca custa 200 créditos, não atira, não gera créditos por tiro, não possui alcance, modo de alvo ou melhorias e pode ser vendida pelas regras normais.
- Podem existir no máximo 2 Iscas por partida, e ambas contam no limite geral da fase.
- Sabotadores dentro de 180 px, Macacos dentro de 165 px e Corujas dentro de 190 px priorizam qualquer Isca no próprio alcance mesmo quando outra torre está mais próxima.
- Sabotadores, Macacos e Corujas consomem 1 dos 10 pontos de resistência a cada impacto; o décimo destrói a Isca sem devolver créditos.
- Na ausência de Isca dentro do alcance, Sabotadores, Macacos e Corujas mantêm seu comportamento anterior.
- Na campanha normal, a wave 1 não concede Fragmentos. Da wave 2 em diante, a recompensa é igual à wave alcançada: wave 2 concede 2, wave 3 concede 3, wave 14 concede 14 e vencer a wave 20 concede 20.
- Reiniciar não concede Fragmentos. Confirmar **Desistir** ou sofrer derrota concede a recompensa calculada; fechar a página sem confirmar não concede.
- No modo infinito, desistência ou derrota concede 1 Fragmento a cada 2 waves, ignorando a wave ímpar sem par completo.

### Mudança: Amplificador Pixel

**Objetivo:** adicionar uma torre de suporte que fortaleça posições planejadas sem substituir as torres de combate.
**Alterar:** adicionar o Amplificador Pixel como compra permanente da Loja por 45 Fragmentos e construção de 300 créditos.
**Não alterar:** dano, alcance e cadência base das torres existentes, limites gerais por fase, economia por disparo ou desbloqueios da campanha.
**Aceitação:**
- Sem a compra, o botão do Amplificador permanece desabilitado e mostra **Compre na Loja**.
- Depois da compra, o Amplificador fica disponível em todas as fases e continua liberado após atualizar a página.
- Cada Amplificador custa 300 créditos, não atira, não gera créditos, não possui melhorias nem modo de alvo e conta no limite geral da fase.
- Pode existir no máximo 1 Amplificador por partida.
- Torres de combate a até 135 px do Amplificador têm seu intervalo de ataque reduzido em 15%.
- A Isca Blindada, o próprio Amplificador e outras estruturas sem ataque não recebem o bônus.
- Sobreposição de auras nunca acumula o bônus; somente o maior bônus de suporte aplicável é usado.
- Lentidão do Macaco, bônus pós-Boss e boost do fliperama combinam multiplicativamente com o Amplificador.
- Vender ou perder o Amplificador remove imediatamente o bônus das torres que estavam em sua aura.
- O mapa, o seletor, a Loja e o Álbum usam o mesmo desenho pixelado de antena e exibem o alcance de suporte.

### Mudança: categorias da Loja

**Objetivo:** organizar o catálogo para receber novos tipos de item sem misturar torres, explosivos e aprimoramentos.
**Alterar:** dividir a Loja nas abas **Torres**, **Minas** e **Melhorias**, mantendo o catálogo atual na primeira aba.
**Não alterar:** preços, saldo, persistência das compras, desbloqueios, atributos das torres e recompensas de Fragmentos.
**Aceitação:**
- Ao abrir a Loja, a aba **Torres** começa selecionada e mostra a Isca Blindada e o Amplificador Pixel.
- Cada aba informa quantos itens possui; uma categoria vazia mostra **Em breve**.
- A aba **Torres** usa uma torre com canhão em pixel art, e a aba **Minas** usa uma bomba com pavio aceso em pixel art; os mesmos desenhos aparecem nos painéis vazios dessas categorias.
- **Minas** mostra a Mina Terrestre e a Bomba Pesada disponíveis para compra, enquanto **Melhorias** antecipa aprimoramentos permanentes sem permitir compras ainda.
- Ao selecionar outra aba, apenas o conteúdo do catálogo é trocado; o saldo permanece visível e inalterado.
- Em telas estreitas, as três abas continuam acessíveis na mesma linha com rótulos legíveis.

### Mudança: melhorias permanentes da Loja

**Objetivo:** preencher a categoria **Melhorias** com progressão permanente que complemente as defesas compráveis.
**Alterar:** adicionar **Reserva de Créditos**, **Licença de Construção** e **Recompensa Otimizada** ao catálogo persistente.
**Não alterar:** preços ou atributos das quatro defesas existentes, recompensas de Fragmentos, composição das waves, desbloqueio das fases ou valores-base sem as compras.
**Aceitação:**
- A aba **Melhorias** mostra exatamente três itens, com miniaturas pixeladas, descrição, preço e estado de compra.
- **Reserva de Créditos** custa 30 Fragmentos e faz toda nova partida começar com 200 créditos em vez de 150.
- **Licença de Construção** custa 45 Fragmentos e eleva os limites das Fases 1 a 7 para 11, 13, 13, 15, 17, 19 e 21 torres.
- **Recompensa Otimizada** custa 55 Fragmentos e aumenta de 20 para 22 os créditos concedidos por disparo das torres de combate.
- As três compras são permanentes, não podem ser compradas novamente e continuam ativas depois de atualizar a página.
- O saldo, os créditos iniciais e o limite exibidos no lobby são atualizados imediatamente após a compra correspondente.

### Mudança: Torre de Raios e Mina Congelante

**Objetivo:** ampliar as opções compráveis da Loja com uma torre de múltiplos alvos e uma mina de controle de grupo.
**Alterar:** adicionar a **Torre de Raios** à aba **Torres** e a **Mina Congelante** à aba **Minas**, ambas com compra permanente.
**Não alterar:** preços e atributos dos itens anteriores, limite-base das fases, progressão da campanha, trajetórias ou composição das waves.
**Aceitação:**
- A Torre de Raios custa 60 Fragmentos na Loja e 425 créditos na partida, ocupa uma vaga de torre e permite no máximo 2 unidades por partida.
- Cada disparo da Torre de Raios causa 30 de dano no primeiro alvo e pode saltar para mais 2 inimigos a até 110 px, mantendo 70% do dano a cada salto.
- Um disparo encadeado concede a recompensa de créditos somente uma vez, independentemente da quantidade de inimigos atingidos.
- A Mina Congelante custa 35 Fragmentos na Loja e 125 créditos na partida, deve ser armada sobre o caminho e permite no máximo 4 unidades no mapa.
- A explosão congelante causa 55 de dano em 85 px, aplica 50% de lentidão durante 2.500 ms e congela inimigos comuns durante 800 ms; chefes recebem apenas a lentidão.
- As duas defesas permanecem compradas após atualizar a página, aparecem no seletor e no Álbum e possuem desenhos pixelados próprios.

### Mudança: Lança-Chamas

**Objetivo:** adicionar uma torre comprável de ataque rápido que continue causando dano depois do impacto.
**Alterar:** adicionar o **Lança-Chamas** à aba **Torres** da Loja, ao seletor da partida e ao Álbum depois da compra permanente.
**Não alterar:** preços e atributos das defesas anteriores, limite-base das fases, progressão da campanha, trajetórias, composição das waves ou recompensa por disparo.
**Aceitação:**
- O Lança-Chamas custa 100 Fragmentos na Loja, 650 créditos na partida, ocupa uma vaga de torre e permite no máximo 2 unidades por partida.
- Seu ataque base causa 10 de dano direto, possui 145 px de alcance, dispara bolas de fogo a cada 333 ms e viaja a 9 px por quadro.
- A cadência de 333 ms é aproximadamente 1,5 vez a cadência da Torre padrão de nível 0, cujo intervalo é de 500 ms.
- Cada impacto em um inimigo vivo aplica uma queimadura de 5 de dano a cada 1.000 ms durante 10.000 ms, totalizando até 50 de dano adicional.
- A queimadura não acumula. Um novo impacto antes do término mantém o dano em 5 por intervalo e renova a duração para mais 10.000 ms sem adiar o próximo pulso já programado.
- A queimadura pode eliminar inimigos e respeita as regras especiais de dano dos Bosses.
- Pausar a partida também pausa a duração e os pulsos da queimadura.
- Cada bola de fogo disparada concede a recompensa normal de créditos uma única vez; os pulsos de queimadura não concedem créditos adicionais.
- Loja, seletor, mapa e Álbum usam o mesmo visual pixelado com detalhes laranja, tanque de combustível acoplado e projétil de fogo próprio.
- O nome e as descrições do Lança-Chamas ficam disponíveis em português, inglês e espanhol.

### Mudança: Mina Terrestre

**Objetivo:** adicionar uma defesa consumível de área que recompense o posicionamento no caminho.
**Alterar:** adicionar a Mina Terrestre como compra permanente da Loja por 25 Fragmentos e armamento de 100 créditos durante a partida.
**Não alterar:** limite de torres de cada fase, dano e cadência das torres, recompensas por tiro, trajetórias, composição das waves ou progressão da campanha.
**Aceitação:**
- Sem a compra, o botão da Mina permanece desabilitado e mostra **Compre na Loja**.
- Depois da compra, a Mina fica disponível em todas as fases e continua liberada após atualizar a página.
- A Mina só pode ser armada sobre o caminho dos inimigos; ao clicar na largura do caminho, ela se encaixa no centro do trecho mais próximo. Tentar colocá-la fora dele não desconta créditos.
- Cada Mina custa 100 créditos, causa exatamente 100 de dano aos inimigos cujos centros estejam a até 75 px da explosão e desaparece depois de explodir.
- A explosão só é disparada quando o corpo de um inimigo toca o corpo da Mina, usando o raio físico de 18 px da Mina somado ao tamanho do inimigo; apenas entrar na área de 75 px não dispara a armadilha.
- Podem existir no máximo 5 Minas armadas ao mesmo tempo. Minas precisam manter 40 px de distância entre si, e uma explosão libera imediatamente uma vaga.
- Minas não contam no limite de torres da fase, não bloqueiam a construção de torres próximas e não podem ser selecionadas, melhoradas, vendidas, atacadas ou fortalecidas por bônus.
- Dano de Mina não concede os 20 créditos reservados aos disparos das torres.
- Loja, seletor de defesas, mapa e Álbum usam a mesma aparência pixelada da Mina; a explosão também é desenhada com blocos.

### Mudança: Bomba Pesada

**Objetivo:** oferecer um explosivo manual de maior impacto, diferente da Mina ativada por contato.
**Alterar:** adicionar a Bomba Pesada como compra permanente da Loja por 40 Fragmentos e posicionamento de 200 créditos durante a partida.
**Não alterar:** contato automático da Mina Terrestre, limite de torres de cada fase, recompensas por tiro, trajetórias, composição das waves ou progressão da campanha.
**Aceitação:**
- Sem a compra, o botão da Bomba permanece desabilitado e mostra **Compre na Loja**; depois da compra, ela fica disponível permanentemente em todas as fases.
- A Bomba só pode ser posicionada fora do caminho, custa 200 créditos e não ocupa vaga no limite de torres.
- Podem existir no máximo 3 Bombas Pesadas no mapa. Elas mantêm 50 px de distância entre si e respeitam o espaçamento das torres para continuar clicáveis.
- A Bomba nunca explode por contato. O primeiro clique nela acende um pavio de 1,5 segundo, que não pode ser cancelado; cliques seguintes apenas informam o tempo restante.
- Ao terminar o pavio, a Bomba desaparece e causa exatamente 200 de dano aos inimigos cujos centros estejam a até 100 px da explosão.
- Pausar a partida congela o pavio. Reiniciar ou abandonar a fase remove todas as Bombas e explosões pendentes.
- Bombas não podem ser melhoradas, vendidas, atacadas ou fortalecidas por bônus, e seu dano não concede créditos.
- Loja, seletor, mapa e Álbum usam o mesmo desenho pixelado da Bomba, com pavio piscante durante a contagem.

## Venda de torre

- Clique em uma torre para selecioná-la e use o botão **Vender torre**.
- A venda devolve 60% do valor total investido na torre, incluindo o custo específico do tipo e suas melhorias, equivalente a 40% de desconto.

### Mudança: simulação independente da taxa de atualização

**Objetivo:** manter a mesma dificuldade em monitores de 60 Hz, 120 Hz, 144 Hz ou outras taxas de atualização.
**Alterar:** calcular movimento e duração de efeitos visuais pelo tempo decorrido entre quadros, usando 60 quadros por segundo como referência e limitando cada avanço a no máximo 50 ms.
**Não alterar:** velocidades configuradas, trajetórias, vida, dano, alcance, cadência, composição das waves, economia ou condições de vitória e derrota.
**Aceitação:**
- Os valores existentes em pixels por frame continuam representando a velocidade observada a 60 quadros por segundo.
- Inimigos e projéteis percorrem aproximadamente a mesma distância por segundo em telas de 60 Hz, 120 Hz e 144 Hz.
- Explosões permanecem visíveis pela mesma duração aproximada independentemente da taxa do monitor.
- Um travamento ou atraso maior que 50 ms não provoca um salto descontrolado da simulação.
- Iniciar, reiniciar ou retomar uma partida reinicia a referência de tempo sem mover unidades instantaneamente.

### Mudança: pausa automática ao ocultar a página

**Objetivo:** impedir que o jogador perca tempo de reação, pavios ou boosts ao trocar de aba ou minimizar o navegador.
**Alterar:** pausar automaticamente uma partida ativa quando a página ficar oculta e abrir o menu de pausa para que o jogador escolha quando continuar.
**Não alterar:** pausa manual, música, progresso, recompensas, posições, atributos ou comportamento do lobby e das telas de resultado.
**Aceitação:**
- Ao ocultar a página durante uma batalha ativa, inimigos, projéteis, waves, pavios, avisos e efeitos temporários ficam congelados.
- Ao retornar, o menu **Jogo pausado** permanece aberto e a partida só continua quando o jogador o fechar.
- Se a página for ocultada durante um minigame do fliperama, o tempo oculto não é descontado dos 15 segundos disponíveis.
- Tutoriais, configurações, escolhas pós-Boss e confirmações que já estavam pausadas permanecem no próprio estado sem abrir uma segunda camada.
- Ocultar a página no lobby ou em uma tela de resultado não inicia nem modifica uma partida.

### Mudança: controles de toque do Labirinto Pixel

**Objetivo:** permitir concluir o Labirinto Pixel em celulares e tablets sem teclado físico.
**Alterar:** exibir um direcional de quatro botões durante o Labirinto Pixel em telas de até 760 px ou dispositivos com ponteiro de toque.
**Não alterar:** controles WASD e setas, velocidade do robô, mapas, paredes, duração, colisões ou recompensa do minigame.
**Aceitação:**
- Os botões **cima**, **esquerda**, **baixo** e **direita** aparecem somente quando o Labirinto Pixel está ativo em uma tela estreita ou dispositivo de toque.
- Manter um botão pressionado move o robô continuamente na direção correspondente; soltar ou cancelar o toque interrompe essa direção.
- Dois botões podem ser pressionados ao mesmo tempo para movimento diagonal, com a mesma normalização usada pelo teclado.
- Os botões possuem nomes acessíveis e acompanham o idioma selecionado.
- No Tiro ao alvo, o direcional permanece oculto.

### Mudança: partida compacta em celulares pequenos

**Objetivo:** preservar uma área útil do mapa e manter os controles legíveis em telas de até 480 px.
**Alterar:** empilhar mapa, posto de boosts e seletor de defesas; transformar o seletor em uma lista horizontal rolável e aumentar os menores rótulos da partida.
**Não alterar:** tamanho interno de 1.200 × 700 px do mapa, posições do caminho, áreas de clique, quantidade de defesas, ordem dos botões ou layout do lobby.
**Aceitação:**
- Em telas de até 480 px, o seletor de defesas deixa de consumir uma coluna ao lado do mapa e aparece abaixo dele.
- O mapa usa toda a largura disponível antes do posto de boosts e do seletor horizontal.
- O posto de boosts deixa de cobrir o mapa e organiza bônus permanentes e temporários em uma faixa abaixo dele.
- Todos os tipos de defesa continuam acessíveis por rolagem horizontal e mantêm alvos de toque com pelo menos 54 px de altura.
- Textos essenciais do seletor, boosts e ações permanecem legíveis sem modificar o layout de telas maiores.

### Mudança: fase secreta Dimensão Glitch

**Objetivo:** permitir que o jogador encontre uma fase escondida no próprio lobby, sem revelar sua existência no seletor comum da campanha.
**Alterar:** manter um portal corrompido aceso e parcialmente coberto pela primeira árvore do lobby da Fase 1; clicar nele corrompe toda a tela, teleporta imediatamente o jogador para a **Dimensão Glitch** e revela o **Senhor do Tempo**.
**Não alterar:** ordem e desbloqueio das sete fases da campanha, maior fase concluída, atributos das torres, preços, recompensas por disparo, intervalo de Boss ou quantidade padrão de 20 waves.
**Aceitação:**
- O portal existe somente no cenário de lobby da Fase 1, fica visualmente atrás da primeira árvore e permanece aceso com brilho preto, roxo e ciano.
- Clicar no portal funciona independentemente da maior fase concluída, registra imediatamente a descoberta em armazenamento local e impede cliques repetidos durante o teleporte.
- Não existe painel intermediário nem escolha de resposta: o portal é a única entrada e inicia diretamente uma transição de 1.600 ms.
- Durante a transição, toda a interface sofre deslocamentos, inversões de cor, separação dos canais ciano e magenta, cortes horizontais e uma camada de ruído com as mensagens **SINAL CORROMPIDO** e **A realidade está falhando...**.
- A música do lobby para, começa a composição procedural assustadora e corrompida do portal e toca um efeito sintetizado exclusivo com quatro notas quebradas e ruído filtrado.
- A faixa usada na transição continua sendo a composição procedural assustadora e corrompida exclusiva desse diálogo de chegada, com passos de 540 ms e ganho relativo de 185%.
- A música da conversa usa oito notas graves entre 92,5 e 155,56 Hz, dois baixos em 58,27 e 65,41 Hz, intervalos dissonantes e ruído filtrado; essa faixa preserva o clima grave sem desaparecer nos alto-falantes de celulares e notebooks. Sua melodia, ritmo e síntese são diferentes da música da Dimensão Glitch.
- Ao terminar a transição, o jogo seleciona o número interno 8, abre o mapa da Dimensão Glitch e mantém a simulação pausada antes que qualquer inimigo avance.
- O tutorial comum da primeira partida não aparece quando a entrada ocorre pelo portal.
- Sobre o mapa surge o mesmo balão largo e baixo da conversa anterior, com o retrato pixelado misterioso do Senhor do Tempo: corpo geométrico escuro com falhas ciano e magenta, cuja cabeça é um relógio animado.
- A primeira fala do personagem é **Era eu quem falava com você através do portal.**; a segunda é **Meu nome é Senhor do Tempo.**, momento em que o nome substitui **???** no balão.
- As falas seguintes são, em ordem: **Você não tem escolha.**, **Se quiser sair, vai ter que sair vitorioso daqui.**, **Supere as 20 waves e eu abrirei o caminho de volta.**, **Serei generoso com você. Afinal, poucas pessoas chegam até aqui. Darei 300 créditos a mais para você começar. Mas depois disso você pensa que acabou? Ainda não.** e **Agora lute. O tempo já começou a correr.**
- A generosidade anunciada é real: toda tentativa na Dimensão Glitch começa com **300 créditos adicionais**, somados aos créditos iniciais normais e às melhorias permanentes da Loja, sem alterar o dinheiro inicial das demais fases.
- Um único botão **Continuar** avança as falas; na última, ele muda para **Enfrentar a Dimensão**. A conversa não pode ser fechada clicando fora nem usando Escape.
- Somente após a última fala a camada desaparece e a simulação é retomada.
- Na Dimensão Glitch, o comando **Desistir** vira **Saída bloqueada** e fica desabilitado. Depois de uma derrota, o botão de voltar ao menu não aparece; o jogador pode apenas recomeçar a fase.
- Ao vencer as 20 waves, o Senhor do Tempo libera a saída e o botão de voltar ao menu reaparece.
- A Dimensão Glitch nunca é adicionada a `CONFIG.fases` nem aos cartões da tela **Fases**. Ela usa o número interno 8 apenas para carregar seu mapa e seu limite.
- A fase secreta possui 20 waves, limite-base de 12 torres e Boss nas waves 5, 10, 15 e 20.
- Cada wave possui `3 + wave` Pixels Corrompidos. O Erro Veloz aparece na wave 3 e ganha uma unidade a cada 2 waves; o Bloco Instável aparece na wave 5 e ganha uma unidade a cada 4 waves.
- O Pixel Corrompido possui 190 de vida, velocidade 1,55 e tamanho 22; seu desenho usa os quatro blocos preto/roxo e as partes ausentes da referência criada pelo jogador, com pequenos pixels ciano para contraste.
- O Erro Veloz possui 280 de vida, velocidade 2,45 e tamanho 20. O Bloco Instável possui 780 de vida, velocidade 0,78 e tamanho 33.
- O Núcleo Glitch possui 2.600 de vida na primeira aparição, ganha 450 de vida por aparição, tem velocidade 0,9 e tamanho 48.
- O mapa usa terreno escuro, falhas roxas e ciano e uma trajetória própria. Esses inimigos aparecem no Álbum somente depois que o portal é atravessado pela primeira vez.
- Concluir a fase concede os Fragmentos normais pelas waves e conta para missões e conquistas de partidas concluídas, mas não aumenta a maior fase da campanha nem libera uma nova fase.
- A primeira vitória na Dimensão Glitch desbloqueia a conquista especial **???**, com a descrição **Ainda está te esperando, sempre vai estar.**
- Ao voltar ao lobby depois de jogar a fase secreta, a seleção retorna à Fase 1 e o portal continua sendo a única entrada.
- Ao entrar na Dimensão Glitch, todas as outras trilhas são encerradas e começa sua música procedural exclusiva, em passos de 310 ms e com ganho relativo de 175%.
- A trilha usa 16 notas, quatro baixos graves, desafinação controlada, ruídos curtos e três repetições digitais nos passos 8 e 16 de cada ciclo.
- Silenciar, reativar ou ajustar o volume da música afeta a trilha secreta imediatamente; ao voltar ao lobby, ela é encerrada antes da música do lobby.
- Se Web Audio não estiver disponível, a fase secreta usa `background_music.mp3` como alternativa.

### Conceito futuro: forma humana do Senhor do Tempo

**Objetivo:** preservar para uma atualização futura o retrato humano aprovado, sem exibi-lo na versão atual.
**Alterar:** manter o conceito guardado em `CONFIG.faseSecreta.senhorDoTempo.formaHumanaFutura`, inicialmente com `ativa: false`.
**Não alterar:** conversa atual do portal, conteúdo atual do Álbum, inimigos, progressão, falas ou balanceamento da Dimensão Glitch.
**Aceitação:**
- Enquanto `ativa` for `false`, a forma humana não aparece no balão e não cria figurinha, nome, descrição ou espaço adicional na página **Inimigos** do Álbum.
- O balão atual volta a usar o corpo geométrico escuro com detalhes ciano e magenta e mantém a cabeça de relógio animada.
- O conceito futuro preserva corpo humano alto de meio-corpo, cabeça proporcionalmente menor, torso comprido, ombros largos, terno escuro, camisa clara, gravata vermelha, braços grossos proporcionais ao torso, um braço relaxado e o outro em um bolso baixo do paletó próximo à cintura.
- O desenho pixelado, as cores, o cartão futuro e os estilos ficam guardados no código; uma atualização posterior pode ativá-los alterando somente a opção `ativa` para `true`.

### Validação automatizada no navegador

- A suíte de ponta a ponta abre o jogo em um servidor local e usa um navegador real.
- Os cenários cobrem iniciar uma partida, construir e selecionar uma torre e abrir a pausa; salvar e restaurar áudio e iluminação; cancelar e confirmar uma compra da Loja; e mostrar avisos de missão e conquista.
- Cada cenário começa com armazenamento local controlado para não depender do progresso manual de outra execução.
- Os testes de estrutura existentes continuam sendo executados separadamente para detectar regressões rápidas em regras e conteúdo.

## Critérios de aceitação

Uma alteração de mecânica deve declarar:

1. Qual regra atual será modificada.
2. O novo comportamento observável pelo jogador.
3. Valores exatos, limites e condições de início/fim.
4. O que deve permanecer igual.

### Modelo de requisito

```md
## Mudança: <nome>

**Objetivo:** <resultado para o jogador>.
**Alterar:** <regra e valor atual para novo valor>.
**Não alterar:** <comportamentos preservados>.
**Aceitação:**
- Dado <estado>, quando <ação>, então <resultado>.
```
