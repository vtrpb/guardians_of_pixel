const { test, expect } = require("@playwright/test");

const CHAVE_TUTORIAL = "guardians-of-pixel-tutorial-concluido-v1";
const CHAVE_FRAGMENTOS = "guardians-of-pixel-fragmentos-v2";
const CHAVE_COMPRAS = "guardians-of-pixel-compras-v2";
const CHAVE_PREFERENCIAS = "guardians-of-pixel-preferencias-v1";

test.beforeEach(async ({ page }) => {
    await page.addInitScript((chaveTutorial) => {
        const chaveDaSessaoDeTeste = "guardians-of-pixel-e2e-inicializado";
        if (sessionStorage.getItem(chaveDaSessaoDeTeste) !== "true") {
            localStorage.clear();
            sessionStorage.setItem(chaveDaSessaoDeTeste, "true");
        }
        localStorage.setItem(chaveTutorial, "true");
    }, CHAVE_TUTORIAL);
});

test("abre as áreas de consulta como páginas inteiras e preserva configurações e portal", async ({ page }) => {
    await page.setViewportSize({ width: 1363, height: 756 });
    await page.goto("/");

    const paginas = [
        { tela: "album", seletor: 'button[onclick="mostrarAlbum()"]' },
        { tela: "fases", seletor: 'button[onclick="mostrarFases()"]' },
        { tela: "tutorial", seletor: 'button[onclick="mostrarTutorial()"]' },
        { tela: "loja", seletor: ".botao-lobby-loja" },
        { tela: "pacoteApoiador", seletor: ".botao-lobby-apoiador" },
        { tela: "missoes", seletor: ".botao-lobby-missoes" },
        { tela: "conquistas", seletor: ".botao-lobby-conquistas" }
    ];
    const conteudo = page.locator("#conteudo-menu");
    const menu = page.locator("#menu-principal");

    for (const [indice, pagina] of paginas.entries()) {
        const botaoDeOrigem = page.locator(pagina.seletor);
        await botaoDeOrigem.click();
        await expect(conteudo).toHaveClass(/conteudo-menu-tela-cheia/);
        await expect(conteudo).toHaveAttribute("data-tela", pagina.tela);
        await expect(menu).toHaveClass(/pagina-menu-aberta/);
        await expect(conteudo.locator(".botao-fechar")).toBeFocused();

        const caixa = await conteudo.boundingBox();
        expect(caixa).not.toBeNull();
        expect(caixa.x).toBeLessThanOrEqual(0.5);
        expect(caixa.y).toBeLessThanOrEqual(0.5);
        expect(caixa.width).toBeGreaterThanOrEqual(1362);
        expect(caixa.height).toBeGreaterThanOrEqual(755);
        await expect(page.locator(".menu-cartao")).toHaveCSS("overflow", "hidden");

        if (pagina.tela === "album") {
            await page.locator("#aba-album-inimigos").click();
            await expect(page.locator("#aba-album-inimigos")).toHaveAttribute("aria-selected", "true");
            await expect(conteudo).toHaveAttribute("data-tela", "album");
        }

        if (pagina.tela === "loja") {
            const abaDeMinas = page.locator('button[onclick="selecionarCategoriaDaLoja(\'minas\')"]');
            await abaDeMinas.click();
            await expect(abaDeMinas).toHaveAttribute("aria-selected", "true");
            await expect(conteudo).toHaveAttribute("data-tela", "loja");
        }

        if (indice === paginas.length - 1) {
            await page.keyboard.press("Escape");
        } else {
            await conteudo.locator(".botao-fechar").click();
        }

        await expect(conteudo).toBeHidden();
        await expect(menu).not.toHaveClass(/pagina-menu-aberta/);
        await expect(botaoDeOrigem).toBeFocused();
    }

    await page.locator("#botao-configuracoes-lobby").click();
    await expect(page.locator("#camada-configuracoes")).toBeVisible();
    await expect(conteudo).not.toHaveClass(/conteudo-menu-tela-cheia/);
    await page.locator(".botao-fechar-configuracoes").click();

    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator('button[onclick="mostrarAlbum()"]').click();
    const caixaCompacta = await conteudo.boundingBox();
    expect(caixaCompacta).not.toBeNull();
    expect(caixaCompacta.width).toBeGreaterThanOrEqual(389);
    expect(caixaCompacta.height).toBeGreaterThanOrEqual(843);
    await expect(conteudo.locator(".botao-fechar")).toBeVisible();
    await conteudo.locator(".botao-fechar").click();
    await page.setViewportSize({ width: 1363, height: 756 });

    await page.locator("#portal-fase-secreta").click({ force: true });
    await expect(page.locator("#camada-transicao-glitch")).toBeVisible();
    await expect(page.locator("#camada-conversa-portal")).toBeVisible({ timeout: 5000 });
    await expect(page.locator(".senhor-tempo-cabeca")).toBeVisible();
    await expect(page.locator(".senhor-tempo-corpo")).toBeVisible();
    await expect(page.locator(".senhor-tempo-forma-humana")).toHaveCount(0);
    await expect(page.locator(".senhor-tempo-braco")).toHaveCount(0);
    await expect(page.locator(".conversa-portal-fala")).toContainText(
        "Era eu quem falava com você através do portal."
    );
    await expect(conteudo).not.toHaveClass(/conteudo-menu-tela-cheia/);
    await expect(menu).not.toHaveClass(/pagina-menu-aberta/);
});

test("revela o Senhor do Tempo e prende o jogador até vencer a Dimensão Glitch", async ({ page }) => {
    await page.goto("/");
    await page.locator("#portal-fase-secreta").click({ force: true });
    const conversa = page.locator("#camada-conversa-portal");
    const fala = conversa.locator(".conversa-portal-fala");
    const avancar = conversa.locator(".botao-avancar-senhor-tempo");

    await expect(conversa).toBeVisible({ timeout: 5000 });
    await expect(fala).toContainText("Era eu quem falava com você através do portal.");
    expect(await page.evaluate(() => eval("({ faseSelecionada, jogoPausado, wave, dinheiro })"))).toEqual({
        faseSelecionada: 8,
        jogoPausado: true,
        wave: 1,
        dinheiro: 450
    });

    const falasSeguintes = [
        "Meu nome é Senhor do Tempo.",
        "Você não tem escolha.",
        "Se quiser sair, vai ter que sair vitorioso daqui.",
        "Supere as 20 waves e eu abrirei o caminho de volta.",
        "Serei generoso com você. Afinal, poucas pessoas chegam até aqui. Darei 300 créditos a mais para você começar. Mas depois disso você pensa que acabou? Ainda não.",
        "Agora lute. O tempo já começou a correr."
    ];

    for (const falaEsperada of falasSeguintes) {
        await avancar.click();
        await expect(fala).toContainText(falaEsperada);

        if (falaEsperada.startsWith("Serei generoso")) {
            await page.setViewportSize({ width: 390, height: 844 });
            const caixaDoBalao = await conversa.locator(".balao-senhor-do-tempo").boundingBox();
            expect(caixaDoBalao).not.toBeNull();
            expect(caixaDoBalao.x).toBeGreaterThanOrEqual(0);
            expect(caixaDoBalao.y).toBeGreaterThanOrEqual(0);
            expect(caixaDoBalao.x + caixaDoBalao.width).toBeLessThanOrEqual(390);
            expect(caixaDoBalao.y + caixaDoBalao.height).toBeLessThanOrEqual(844);
            await expect(avancar).toBeVisible();
            await page.setViewportSize({ width: 1440, height: 1000 });
        }
    }

    await expect(conversa.getByRole("heading", { name: "Senhor do Tempo" })).toBeVisible();
    await expect(avancar).toHaveText("Enfrentar a Dimensão");
    await avancar.click();
    await expect(conversa).toBeHidden();
    await expect.poll(() => page.evaluate(() => eval("jogoPausado"))).toBe(false);

    await page.locator("#botao-menu-partida").click();
    await expect(page.locator("#botao-desistir-menu")).toBeDisabled();
    await expect(page.locator("#botao-desistir-menu")).toContainText("Saída bloqueada");
    await page.locator("#botao-menu-partida").click();

    await page.evaluate(() => finalizarPartida());
    await expect(page.locator("#camada-resultado")).toBeVisible();
    await expect(page.locator("#descricao-resultado")).toContainText(
        "A derrota não abriu a saída. O Senhor do Tempo exige uma vitória."
    );
    await expect(page.locator("#botao-voltar-lobby-resultado")).toBeHidden();
    await expect(page.locator("#botao-repetir-resultado")).toBeVisible();
});

test("inicia o Álbum sem inimigos e revela somente figurinhas conquistadas", async ({ page }) => {
    await page.addInitScript(() => {
        localStorage.setItem("tower-defense-2-progresso-fases-v2", "3");
        localStorage.setItem("guardians-of-pixel-fragmentos-v2", "77");
        localStorage.setItem(
            "guardians-of-pixel-compras-v2",
            JSON.stringify(["minaTerrestre"])
        );
    });
    await page.goto("/");
    await page.locator('button[onclick="mostrarAlbum()"]').click();

    const conteudo = page.locator("#conteudo-menu");
    await expect(conteudo.getByRole("heading", { name: "Álbum de Figurinhas" })).toBeVisible();
    await expect(conteudo.locator('[data-tipo-torre="padrao"]')).toHaveCount(4);
    await expect(conteudo.locator('[data-tipo-torre="torreBesta"]')).toHaveCount(4);
    await expect(conteudo.locator('[data-tipo-torre="torreEsporos"]')).toHaveCount(0);

    await conteudo.locator("#aba-album-inimigos").click();
    await expect(conteudo.locator(".album-vazio")).toBeVisible();
    await expect(conteudo.locator(".album-cartao-inimigo")).toHaveCount(0);
    await expect(conteudo.getByText("0 de 21 figurinhas coladas")).toBeVisible();

    const contaPreservada = await page.evaluate(() => ({
        progresso: localStorage.getItem("tower-defense-2-progresso-fases-v2"),
        fragmentos: localStorage.getItem("guardians-of-pixel-fragmentos-v2"),
        compras: localStorage.getItem("guardians-of-pixel-compras-v2"),
        figurinhas: localStorage.getItem("guardians-of-pixel-album-figurinhas-v1")
    }));
    expect(contaPreservada).toEqual({
        progresso: "3",
        fragmentos: "77",
        compras: JSON.stringify(["minaTerrestre"]),
        figurinhas: null
    });

    const primeiraDescoberta = await page.evaluate(() =>
        window.registrarInimigoDerrotadoNoAlbum("normal")
    );
    expect(primeiraDescoberta).toBe(true);
    await conteudo.locator("#aba-album-inimigos").click();
    await expect(conteudo.locator('[data-tipo-inimigo="normal"]')).toHaveCount(1);
    await expect(conteudo.locator('[data-tipo-inimigo="elite"]')).toHaveCount(0);
    await expect(conteudo.locator(".album-vazio")).toHaveCount(0);

    const descobertaRepetida = await page.evaluate(() =>
        window.registrarInimigoDerrotadoNoAlbum("normal")
    );
    expect(descobertaRepetida).toBe(false);
    await expect.poll(() => page.evaluate(() =>
        localStorage.getItem("guardians-of-pixel-album-figurinhas-v1")
    )).toBe(JSON.stringify(["normal"]));

    await conteudo.locator("#aba-album-bosses").click();
    await expect(conteudo.locator(".album-vazio")).toBeVisible();
    await conteudo.locator("#aba-album-minas").click();
    await expect(conteudo.locator('[data-tipo-torre="minaTerrestre"]')).toHaveCount(1);
    await expect(conteudo.locator('[data-tipo-torre="bombaPesada"]')).toHaveCount(0);
    await conteudo.locator("#aba-album-skins").click();
    await expect(conteudo.locator('[data-id-skin="original"]')).toHaveCount(1);
    await expect(conteudo.locator('[data-id-skin="sentinelaDourada"]')).toHaveCount(0);
    await expect(conteudo.locator('[data-id-skin="auroraPixel"]')).toHaveCount(0);
});

test("mantém a forma humana futura guardada e fora do Álbum", async ({ page }) => {
    await page.addInitScript(() => {
        localStorage.setItem("guardians-of-pixel-fase-secreta-v1", "true");
    });
    await page.goto("/");
    await page.locator('button[onclick="mostrarAlbum()"]')
        .click();
    await page.locator("#aba-album-inimigos").click();

    await expect(page.locator(".album-cartao-conceito")).toHaveCount(0);
    await expect(page.locator('[data-tipo-inimigo="senhorDoTempoHumano"]')).toHaveCount(0);
    await expect(page.locator(".album-cartao-inimigo")).toHaveCount(0);
    await expect(page.locator(".album-vazio")).toBeVisible();
    await expect(page.getByText("0 de 24 figurinhas coladas")).toBeVisible();
});

test("desbloqueia, seleciona e inicia a Fase 7 no Pântano Tóxico", async ({ page }) => {
    await page.goto("/");
    await page.evaluate(() => {
        localStorage.setItem("tower-defense-2-progresso-fases-v2", "6");
    });
    await page.reload();
    await page.locator('button[onclick="mostrarFases()"]')
        .click();

    const cartaoDoPantano = page.locator(".fase-tema-pantano");
    await expect(cartaoDoPantano).toBeVisible();
    await expect(cartaoDoPantano).toContainText("07");
    await expect(cartaoDoPantano).toContainText("Pântano Tóxico");
    await expect(cartaoDoPantano).toContainText("Disponível");
    await expect(cartaoDoPantano).toContainText("20 waves");

    const botaoSelecionar = cartaoDoPantano.locator(".botao-fase-acao");
    await expect(botaoSelecionar).toBeEnabled();
    await botaoSelecionar.click();
    await expect(cartaoDoPantano).toHaveClass(/fase-cartao-selecionado/);
    await expect(page.locator("#menu-principal")).toHaveClass(/tema-pantano/);

    await page.locator("#conteudo-menu .botao-fechar").click();
    await page.locator(".botao-lobby-jogar").click();
    await expect(page.locator("#game")).toBeVisible();
    expect(await page.evaluate(() => eval(`({
        faseSelecionada,
        tema: obterFaseAtual().tema,
        limite: obterLimiteDeTorres(),
        wave,
        musicaDoPantano: trilhaDoPantanoAtiva
    })`))).toEqual({
        faseSelecionada: 7,
        tema: "pantano",
        limite: 20,
        wave: 1,
        musicaDoPantano: true
    });
});

test("cola a figurinha de um inimigo derrotado durante uma partida real", async ({ page }) => {
    await page.goto("/");
    await page.locator(".botao-lobby-jogar").click();

    const canvas = page.locator("#game");
    const caixa = await canvas.boundingBox();
    expect(caixa).not.toBeNull();
    const posicaoDaTorre = {
        x: caixa.width * 255 / 1200,
        y: caixa.height * 375 / 700
    };
    await canvas.click({ position: posicaoDaTorre });
    await canvas.click({ position: posicaoDaTorre });
    await expect(page.locator("#botao-vender")).toBeEnabled();

    await expect.poll(async () => {
        const valorSalvo = await page.evaluate(() =>
            localStorage.getItem("guardians-of-pixel-album-figurinhas-v1")
        );
        return JSON.parse(valorSalvo || "[]");
    }, { timeout: 30000 }).toContain("normal");

    await page.reload();
    await page.locator('button[onclick="mostrarAlbum()"]').click();
    await page.locator("#aba-album-inimigos").click();
    await expect(page.locator('[data-tipo-inimigo="normal"]')).toHaveCount(1);
    await expect(page.locator('[data-tipo-inimigo="elite"]')).toHaveCount(0);
});

test("amplia o mapa sem distorcer nem cobrir os controles", async ({ page }) => {
    await page.setViewportSize({ width: 1363, height: 756 });
    await page.goto("/");
    await page.locator(".botao-lobby-jogar").click();

    const caixaMapa = await page.locator("#game").boundingBox();
    const caixaSeletor = await page.locator("#seletor-torres").boundingBox();
    const caixaControles = await page.locator(".controles").boundingBox();

    expect(caixaMapa).not.toBeNull();
    expect(caixaSeletor).not.toBeNull();
    expect(caixaControles).not.toBeNull();
    expect(caixaMapa.width).toBeGreaterThanOrEqual(1080);
    expect(caixaMapa.height).toBeGreaterThanOrEqual(630);
    expect(Math.abs(caixaMapa.width / caixaMapa.height - 12 / 7)).toBeLessThan(0.01);
    expect(caixaSeletor.height).toBeGreaterThanOrEqual(600);
    expect(caixaMapa.y + caixaMapa.height).toBeLessThan(caixaControles.y);
    expect(caixaSeletor.y + caixaSeletor.height).toBeLessThan(caixaControles.y);
    expect(caixaControles.y + caixaControles.height).toBeLessThanOrEqual(756 - 18);
});

test("inicia uma partida, constrói, seleciona uma torre e pausa", async ({ page }) => {
    await page.goto("/");
    await page.locator(".botao-lobby-jogar").click();
    await expect(page.locator("#menu-principal")).toHaveClass(/oculto/);
    await expect(page.locator("#seletor-torres")).not.toHaveClass(/oculto/);

    const canvas = page.locator("#game");
    const caixa = await canvas.boundingBox();
    expect(caixa).not.toBeNull();
    const pontosInternos = [
        { x: 700, y: 350 },
        { x: 950, y: 650 },
        { x: 450, y: 350 }
    ];

    for (const ponto of pontosInternos) {
        const posicao = {
            x: caixa.width * ponto.x / 1200,
            y: caixa.height * ponto.y / 700
        };
        await canvas.click({ position: posicao });
        await canvas.click({ position: posicao });

        if (await page.locator("#botao-vender").isEnabled()) {
            break;
        }
    }

    await expect(page.locator("#botao-vender")).toBeEnabled();
    await page.locator("#botao-menu-partida").click();
    await expect(page.locator("#painel-menu-partida")).toBeVisible();
    await expect(page.locator("#painel-menu-partida")).toContainText("Jogo pausado");
});

test("restaura volumes, efeitos desligados e modo noturno", async ({ page }) => {
    await page.goto("/");
    await page.locator("#botao-configuracoes-lobby").click();
    await page.locator("#controle-volume-musica").fill("17");
    await page.locator("#controle-volume-efeitos").fill("63");
    await page.locator("#botao-efeitos-sonoros").click();
    await page.locator("#botao-modo-dia-noite").click();

    await expect.poll(async () => page.evaluate((chave) => (
        JSON.parse(localStorage.getItem(chave)).modoNoturno
    ), CHAVE_PREFERENCIAS)).toBe(true);

    await page.reload();
    await page.locator("#botao-configuracoes-lobby").click();
    await expect(page.locator("#controle-volume-musica")).toHaveValue("17");
    await expect(page.locator("#controle-volume-efeitos")).toHaveValue("63");
    await expect(page.locator("#botao-efeitos-sonoros")).toHaveAttribute("aria-pressed", "false");
    await expect(page.locator("body")).toHaveClass(/modo-noturno/);
});

test("cancela e confirma uma compra sem descontar duas vezes", async ({ page }) => {
    await page.goto("/");
    await page.evaluate((chave) => localStorage.setItem(chave, "100"), CHAVE_FRAGMENTOS);
    await page.reload();
    await page.locator(".botao-lobby-loja").click();
    const botaoDaIsca = page.locator('[data-id-item-loja="iscaBlindada"]');
    await botaoDaIsca.click();
    await expect(page.locator("#camada-confirmacao-compra-loja")).toBeVisible();
    await expect(page.locator("#descricao-confirmacao-compra-loja")).toContainText("70 Fragmentos");
    await page.locator("#botao-cancelar-compra-loja").click();
    await expect(page.locator("#camada-confirmacao-compra-loja")).toBeHidden();
    await expect.poll(async () => page.evaluate((chave) => localStorage.getItem(chave), CHAVE_FRAGMENTOS)).toBe("100");

    await botaoDaIsca.click();
    await page.locator("#botao-confirmar-compra-loja").click();
    await expect.poll(async () => page.evaluate((chave) => localStorage.getItem(chave), CHAVE_FRAGMENTOS)).toBe("70");
    await expect.poll(async () => page.evaluate((chave) => (
        JSON.parse(localStorage.getItem(chave))
    ), CHAVE_COMPRAS)).toContain("iscaBlindada");
    await expect(page.locator('[data-id-item-loja="iscaBlindada"]')).toBeDisabled();
});

test("compra dois Lança-Chamas e incendeia um inimigo em uma partida real", async ({ page }, testInfo) => {
    await page.goto("/");
    await page.evaluate((chave) => localStorage.setItem(chave, "100"), CHAVE_FRAGMENTOS);
    await page.reload();
    await page.locator(".botao-lobby-loja").click();

    const botaoLancaChamas = page.locator('[data-id-item-loja="lancaChamas"]');
    const cartaoLancaChamas = botaoLancaChamas.locator("xpath=ancestor::article");
    await expect(cartaoLancaChamas).toContainText("100◆");
    await expect(cartaoLancaChamas).toContainText("5 de dano por segundo durante 10 segundos");
    await expect(cartaoLancaChamas).toContainText("Custa $650 na partida");
    await expect(cartaoLancaChamas).toContainText("máximo de 2 por partida");

    await botaoLancaChamas.click();
    await page.locator("#botao-confirmar-compra-loja").click();
    await expect.poll(async () => page.evaluate((chave) => (
        JSON.parse(localStorage.getItem(chave))
    ), CHAVE_COMPRAS)).toContain("lancaChamas");
    await expect.poll(async () => page.evaluate((chave) => (
        localStorage.getItem(chave)
    ), CHAVE_FRAGMENTOS)).toBe("0");

    await page.locator("#conteudo-menu .botao-fechar").click();
    await page.locator(".botao-lobby-jogar").click();
    const botaoDeConstrucao = page.locator("#botao-lanca-chamas");
    await expect(botaoDeConstrucao).toBeEnabled();
    await expect(botaoDeConstrucao).toContainText("650");
    await page.evaluate(() => eval("dinheiro = 2000"));
    await botaoDeConstrucao.click();

    const canvas = page.locator("#game");
    const caixa = await canvas.boundingBox();
    expect(caixa).not.toBeNull();
    const converterPosicao = ({ x, y }) => ({
        x: caixa.width * x / 1200,
        y: caixa.height * y / 700
    });
    await canvas.click({ position: converterPosicao({ x: 100, y: 440 }) });
    await canvas.click({ position: converterPosicao({ x: 260, y: 430 }) });
    await canvas.click({ position: converterPosicao({ x: 470, y: 430 }) });

    await expect.poll(() => page.evaluate(() => (
        eval("torres.filter((torre) => torre.tipo === 'lancaChamas').length")
    ))).toBe(2);
    await expect.poll(() => page.evaluate(() => (
        eval("inimigos.some((inimigo) => inimigo.queimaduraExpiraEm > Date.now())")
    )), { timeout: 10000 }).toBe(true);

    await testInfo.attach("lanca-chamas-em-combate", {
        body: await page.screenshot({ type: "png" }),
        contentType: "image/png"
    });
});

test("avisa quando uma missão é concluída", async ({ page }) => {
    await page.goto("/");
    await page.evaluate(() => registrarProgressoDaMissao("inimigosEliminados", 50));
    const aviso = page.locator('.notificacao-progresso[data-tipo="missao"]');
    await expect(aviso).toBeVisible();
    await expect(aviso).toContainText("Missão concluída");
    await expect(aviso).toContainText("Caçador de Pixels");
});

test("avisa quando uma conquista é desbloqueada", async ({ page }) => {
    await page.goto("/");
    await page.evaluate(() => desbloquearConquista("primeiraVigilia"));
    const aviso = page.locator('.notificacao-progresso[data-tipo="conquista"]');
    await expect(aviso).toBeVisible();
    await expect(aviso).toContainText("Conquista desbloqueada");
    await expect(aviso).toContainText("Primeira Vigília");
});
